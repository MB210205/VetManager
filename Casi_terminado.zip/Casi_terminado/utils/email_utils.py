"""
Módulo para envío de correos electrónicos usando SendGrid.

Este módulo define una función para enviar correos utilizando la API HTTP
de SendGrid y el paquete `requests`, validando el certificado con `certifi`.

Variables de entorno requeridas:
- SENDGRID_API_KEY: clave API de SendGrid
- SENDGRID_SENDER: dirección de correo del remitente autorizado
"""
import os
import requests
import certifi
from dotenv import load_dotenv

load_dotenv()
SG_API_KEY    = os.getenv("SENDGRID_API_KEY")
SG_SENDER     = os.getenv("SENDGRID_SENDER")
SENDGRID_URL  = "https://api.sendgrid.com/v3/mail/send"
CA_BUNDLE     = certifi.where()

def send_email(subject: str, body: str, to: str):
    """
    Envía un correo electrónico utilizando la API de SendGrid.
    """
    if not SG_API_KEY or not SG_SENDER:
        raise RuntimeError("Faltan SENDGRID_API_KEY o SENDGRID_SENDER en el entorno")

    headers = {
        "Authorization": f"Bearer {SG_API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "personalizations": [{"to": [{"email": to}]}],
        "from": {"email": SG_SENDER},
        "subject": subject,
        "content": [{"type": "text/plain", "value": body}]
    }

    resp = requests.post(
        SENDGRID_URL,
        headers=headers,
        json=data,
        verify=CA_BUNDLE, # fuerza uso de certifi
        timeout=10  # ⏱️ límite máximo de espera en segundos
    )
    if resp.status_code != 202:
        # levantamos para ver el error completo
        raise RuntimeError(f"Error SendGrid {resp.status_code}: {resp.text}")
