from nicegui import ui
from controladores.logica_restablecer import cambiar_contrasenia



# ✅ RESTABLECER CONTRASEÑA
@ui.page('/reset-password')
def reset_password(access_token: str = ''):
    """
    Página para restablecer la contraseña del usuario.
    Esta función maneja la captura del token de acceso que Supabase
    incluye en la URL después del signo # (hash), y lo convierte en un 
    parámetro de consulta (query parameter) para que el backend en Python 
    pueda recibirlo.
    """
    if not access_token:
        ui.label('🔄 Redirigiendo...')
        ui.add_head_html('''
        <script>
            const hash = window.location.hash.substring(1);
            if (hash.includes("access_token")) {
                const params = new URLSearchParams(hash);
                window.location.href = "/reset-password?" + params.toString();
            }
        </script>
        ''')
        return

    ui.add_head_html('''
        <style>
            html, body {
                margin: 0;
                padding: 0;
                height: 100%;
                font-family: 'Poiret One', sans-serif;
                background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                            url('https://img.freepik.com/vector-premium/ilustracion-vectorial-patron-costuras-pata-gato-huella-pata-gato-aislada-sobre-fondo-blanco_478768-259.jpg?w=2000');
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
            }
            .titulo-vet {
                top: 20px;
                left: 20px;
                color: #1e293b;
                font-size: 80px;
                font-weight: bold;
                font-family: 'Playfair Display', serif;
                user-select: none; 
                cursor: default;
                margin-bottom: 30px; /* Espacio debajo del título */
                text-align: center;
            }
            .custom-input input {
                color: #1e293b;
            }
        </style>
    ''')
#_____
    #CONTENEDOR PRINCPAL
    with ui.column().style('''
            width: 100vw; height: 100vh; display: flex; justify-content: center; align-items: center;
        '''):
       #Card del formulario
        with ui.card().classes('p-10 shadow-xl').style('''
            width: 550px; background-color: #ffffff; border-radius: 24px; color: #1e293b;
            '''):
            ui.label('🐾 Peluchitos').classes('titulo-vet')
            ui.label('Restablecer contraseña').classes('titulo-animado text-4xl mb-8')

            #Nueva contraseña
            with ui.row().classes('w-full mb-6').style('position: relative; align-items: center;'):
                ui.icon('lock').style('''
                    position: absolute; left: 12px; color: #1e293b; font-size: 24px;
                ''')
                nueva = ui.input()\
                    .props('outlined dense type=password outlined dense')\
                        .classes('w-full custom-input')
                nueva.props('placeholder="Nueva contraseña"')
                nueva.style('padding-left: 50px; font-size: 18px; height: 50px;')

            #Confirmar contraseña
            with ui.row().classes('w-full mb-6').style('position: relative; align-items: center;'):
                ui.icon('lock').style('''
                        position: absolute; left: 12px; color: #1e293b; font-size: 24px;
                    ''')
                repetir = ui.input()\
                    .props('outlined dense type=password outlined dense')\
                        .classes('w-full custom-input')
                repetir.props('placeholder="Confirmar contraseña"')
                repetir.style('padding-left: 50px; font-size: 18px; height: 50px;')

            #Recomendación de seguridad
            ui.label('Asegúrate de que la nueva contraseña tenga al menos 8 caracteres.')\
                .classes('text-gray-400 mb-4')

            with ui.column().classes('w-full justify-between mt-6'):
                ui.button("Actualizar Contraseña",
                        on_click=lambda: cambiar_contrasenia(
                            access_token, nueva.value, repetir.value
                        ))\
                    .props('color=primary unelevated')\
                        .classes('w-full font-semibold')\
                            .style('''
                                font-size: 15px; 
                                height: 50px; 
                                border-radius: 10px;
                            ''')

                ui.button("Volver al login",
                        on_click=lambda: ui.run_javascript("window.location.href = '/login';")
                ).classes(
                    'fixed bottom-6 right-6 '
                    'bg-gray-200 hover:bg-gray-300 '
                    'text-gray-800 py-3 px-5 '
                    'rounded-lg shadow-lg '
                    'flex items-center gap-2'
                ).props('unelevated icon=arrow_back_ios').style('z-index: 1000;')
