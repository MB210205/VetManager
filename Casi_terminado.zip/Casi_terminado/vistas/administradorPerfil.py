"""
Módulo AdministradorPerfil

Este módulo contiene la clase AdministradorPerfil, que gestiona las operaciones 
de autenticación y administración de perfiles para veterinarios. 

Proporciona funcionalidades para registrar veterinarios, iniciar y cerrar sesión, 
validar datos de entrada como emails y contraseñas, y editar perfiles de veterinarios.

Utiliza Supabase para autenticación y persistencia de datos en la base de datos.
"""
import re
from smtplib import SMTPException
from postgrest.exceptions import APIError
import httpx
from supabase import AuthApiError
from utils.email_utils import send_email

class AdministradorPerfil:
    """
    Clase para gestionar la autenticación y administración de perfiles de veterinarios.

    Proporciona métodos para registrar veterinarios, iniciar y cerrar sesión, 
    validar emails y contraseñas, y editar información de perfil.

    Utiliza Supabase como backend para autenticación y almacenamiento de datos.
    """
    def __init__(self, dbbroker):
        """
        Inicializa el AdministradorPerfil con una instancia de conexión a la base de datos.
        """
        self.db = dbbroker
        self.auth = dbbroker.supabase.auth  # Supabase Auth


    def registrar_veterinario(self, email, nombre, password, matricula):
        """Registra un nuevo veterinario en Supabase Auth y la tabla 'veterinarians'"""
        if not self.db.existe_matricula_en_padron(matricula):
            return {"ok": False, "error": "La matrícula no figura en nuestro padrón"}

        if not (email and nombre and password):
            return {"ok": False, "error": "Todos los campos son obligatorios"}

        if len(password) < 6:
            return {"ok": False, "error": "La contraseña debe tener al menos 6 caracteres"}

        try:
            # 1) Registro en Supabase Auth
            result = self.auth.sign_up({
                "email": email,
                "password": password
            })
        except AuthApiError as e:
            return {"ok": False, "error": f"Error de autenticación: {e}"}

        if not result.user:
            return {"ok": False, "error": "No se pudo registrar el usuario"}

        try:
            # 2) Inserto registro en tabla veterinarians
            self.db.supabase.table("veterinarians").insert({
                "email": email,
                "name": nombre
            }).execute()
        except APIError as e:
            return {"ok": False, "error": f"Error al guardar en veterinarians: {e}"}

        # 3) Envío email de bienvenida
        subject = "¡Bienvenido a Peluchitos!"
        body = (
            f"Hola {nombre},\n\n"
            "Gracias por unirte a Peluchitos. "
            "Tu cuenta de veterinario ha sido creada ✨exitosamente✨\n\n"
            "Te invitamos a que completes tus datos personales, "
            "así terminas de configurar tu perfil :)\n\n"
            "Un saludo,\n\n"
            "El equipo de Peluchitos"
        )
        try:
            send_email(subject, body, email)
            print(f"[✔] Email de bienvenida enviado con éxito a {email}")
        except SMTPException as e:
            print(f"[✖] Error SMTP al enviar email de bienvenida a {email}: {e}")

        return {"ok": True, "data": {"id": result.user.id, "email": email, "name": nombre}}

    def login_veterinario(self, email, password):
        """
        Inicia sesión de un veterinario con email y contraseña,
        capturando sólo las excepciones específicas.
        """
        if not (email and password):
            return {"ok": False, "error": "Email y contraseña son obligatorios"}

        # 1) Intentar autenticación
        try:
            result = self.auth.sign_in_with_password({
                "email": email,
                "password": password
            })
        except AuthApiError as e:
            return {"ok": False, "error": f"Error de autenticación: {e}"}

        if result.user is None:
            msg = result.error.message if result.error else "Error desconocido"
            return {"ok": False, "error": msg}

        # 2) Traer datos extra del veterinario
        try:
            vet = self.db.get_veterinarian_by_email(email)
        except APIError as e:
            return {"ok": False, "error": f"Error al obtener datos del veterinario: {e}"}
        except httpx.HTTPError as e:
            return {"ok": False, "error": f"Error de conexión al obtener datos: {e}"}

        if vet.data:
            return {"ok": True, "data": vet.data}

        # Si no hay info extra, devolvemos al menos el email
        return {"ok": True, "data": {"email": email}}

    def cerrar_sesion(self):
        """
        Cierra la sesión del usuario autenticado actualmente.
        """
        try:
            self.auth.sign_out()  # Cierra sesión de Supabase
        except AuthApiError as e:
            # Errores de la capa de autenticación Supabase
            print(f"Error al cerrar sesión (AuthApiError): {e}")
        except httpx.HTTPError as e:
            # Errores de red / HTTP subyacente
            print(f"Error al cerrar sesión (HTTPError): {e}")

    def validar_email(self, email):
        """
        Valida si un email tiene un formato válido.
        """
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None

    def validar_password(self, password):
        """
        Valida si una contraseña cumple con los requisitos mínimos.
        """
        if len(password) < 6:
            return False, "La contraseña debe tener al menos 6 caracteres"
        if not any(c.isalpha() for c in password):
            return False, "La contraseña debe contener al menos una letra"
        if not any(c.isdigit() for c in password):
            return False, "La contraseña debe contener al menos un número"
        return True, "Contraseña válida"

    def editar_perfil_veterinario(
        self,
        vet_id,
        email=None,
        nombre=None,
        genero=None,
        phone_number=None,
        age=None,
        address=None,
        profile_imagen=None
    ):
        """
        Edita el perfil del veterinario con los datos proporcionados.
        """
        updates = {}

        if email:
            updates['email'] = email

        if nombre:
            updates['name'] = nombre

        if genero:
            updates['genero'] = genero

        if phone_number:
            updates['phone_number'] = phone_number

        if age is not None:
            updates['age'] = age

        if address:
            updates['address'] = address

        if profile_imagen:
            updates['profile_imagen']= profile_imagen

        if not updates:
            return {'ok': False, 'error': 'No hay cambios para guardar'}

        resp = (self.db.supabase.table("veterinarians").update(updates).eq("id", vet_id).execute())
        if resp.error:
            return {'ok': False, 'error': resp.error.message}
        return {'ok': True, 'data': resp.data}
