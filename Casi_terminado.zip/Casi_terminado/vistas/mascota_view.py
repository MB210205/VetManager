# pylint: disable=unused-import
# pyright: reportUnusedImport=false
# ------------------------
# Módulos estándar de Python
# ------------------------
import os

# ------------------------
# Módulos de terceros
# ------------------------
import httpx
from postgrest.exceptions import APIError
from dotenv import load_dotenv
from nicegui import ui, app #el framework NiceGUI para construir la interfaz web.
from supabase import create_client, AuthApiError

# ------------------------
# Módulos propios - paquetes del proyecto
# ------------------------
from modelos.dbbroker import SupabaseBroker

from modelos.veterinario import Veterinario
from vistas.administradorPerfil import AdministradorPerfil
from vistas.encuesta import Encuesta
from modelos.mascota import Mascota #clase para crear/guardar/editar registros de mascotas.


load_dotenv()
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)


db = SupabaseBroker()
admin = AdministradorPerfil(db)
encuesta = Encuesta()  # usa sqlite:///jobs.sqlite por defecto


@ui.page('/mascotas')
def pets():
    """
    Página principal de selección de categoría de mascotas.

    Esta vista muestra una cuadrícula de tarjetas para que el veterinario seleccione
    una categoría de mascota (Caninos, Felinos, Aves, Roedores, Conejos). Al hacer clic
    en una tarjeta, se redirige a la página correspondiente.

    Funcionalidades:
    - Verifica si el veterinario ha iniciado sesión.
    - Muestra un encabezado fijo con el nombre del sistema y la foto de perfil del veterinario.
    - Ofrece navegación hacia el panel principal y la configuración del perfil.
    - Aplica estilos personalizados y fondo con imagen temática.

    Si no hay sesión activa, redirige a la página de inicio de sesión.
    """
    # Recuperamos el ID de sesión y cargamos al veterinario
    session_veterinarian_id = app.storage.user.get('veterinarian_id')
    if not session_veterinarian_id:
        ui.notify('Debes iniciar sesión', type='warning')
        ui.run_javascript("window.location.href = '/'")
        return

    veterinario = Veterinario(email=None)
    veterinario.cargar_por_id(db, session_veterinarian_id)
    foto_url = getattr(veterinario, 'profile_imagen', None)

    ui.add_body_html('''
        <style>
            .titulo-vet {
                position: fixed;
                top: 20px;
                left: 20px;
                color: #1e293b; /* gris oscuro azulado */
                font-size: 80px;
                font-weight: bold;
                font-family: 'Playfair Display', serif;
                user-select: none; 
                cursor: default;
            }
        </style>
    ''')

    # Contenedor full-screen
    with ui.element().style('''
            margin: 0;
            padding: 0;
            border: 0;
            position: fixed;
            inset: 0;
            width: 100vw;
            height: 100vh;
            font-family: 'Poiret One', sans-serif;
            background: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)),
                         url('https://img.freepik.com/vector-gratis/patron-huellas-gato-o-perro-sobre-fondo-blanco_1017-53330.jpg?t=st=1752270357~exp=1752273957~hmac=c52ce12d82fb9751319d9634e24901cd35520ab59d0e65c6b90661f8c68192f9&w=2000');
            color: #1e293b !important;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        '''):

        # Fila superior: Título a la izquierda, perfil a la derecha (cabecera fija)
        with ui.row().classes(
            'w-full items-center justify-between px-8 py-4 shadow-md backdrop-blur-md' \
            '').style('''
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                z-index: 1000;
                background-color: rgba(255, 255, 255, 0.7);
            '''):

            ui.label('🐾 Peluchitos').classes('titulo-vet') \
            .style('''
                    position: static; 
                    font-size: 80px; 
                    font-weight: bold; 
                    color: #1e293b; 
                    font-family: "Playfair Display", serif; 
                    margin-left: 40px;
                ''')
            ui.label('Selecciona una categoría de mascota').classes('text-h4 text-center').style('''
                color: #1e293b; font-family: "Playfair Display", serif; font-size: 40px
            ''')

            with ui.row().classes('items-center gap-4').style('margin-right: 40px;'):
                if foto_url:
                    # mostramos la imagen subida, ahora más grande
                    ui.image(foto_url) \
                    .classes('w-16 h-16 md:w-20 md:h-20 rounded-full cursor-pointer') \
                    .on('click',
                        lambda: ui.run_javascript("window.location.href = '/configuracion';"))
                else:
                    # icono por defecto
                    ui.button(icon='account_circle',
                        on_click=lambda: ui.run_javascript(
                            "window.location.href = '/configuracion';"
                        )
                    ).props('flat round color=white size=xl')

        # Contenido centrado en pantalla
        with ui.column().classes(
            'absolute top-1/2 left-1/2 '
            'transform -translate-x-1/2 -translate-y-1/2 '
            'items-center gap-10 w-full px-10'
        ):
            colores = ["#83B2DB", "#5B80A0"]

            # grid con 5 columnas y separación amplia entre columnas y filas
            with ui.element().classes(
                'grid grid-cols-1 '
                'sm:grid-cols-2 '
                'md:grid-cols-3 '
                'lg:grid-cols-5 '
                'gap-x-10 gap-y-10'
            ):
                tipos = ['CANINOS', 'FELINOS', 'AVES', 'ROEDORES', 'CONEJOS']
                for i, tipo in enumerate(tipos):
                    color = colores[i % len(colores)]
                    # Cada card con un color diferente
                    with ui.card().style(f'background-color: {color}; color: white;').classes(
                        'w-56 h-56 rounded-2xl flex items-center justify-center text-xl '
                        'cursor-pointer hover:shadow-xl transition-all duration-300'
                    ).on(
                        'click',
                        lambda e, tipo=tipo: ui.run_javascript(
                            f"window.location.href = '/mascotas/{tipo.lower()}'"
                        )
                    ):
                        ui.label(tipo).classes('text-center font-semibold')

        # Botón "Volver" abajo a la derecha
        ui.button("Volver al Panel",
                on_click=lambda: ui.run_javascript("window.location.href = '/principal';")
            ).classes(
                'fixed bottom-6 right-6 '
                'bg-gray-200 hover:bg-gray-300 '
                'text-gray-800 py-3 px-5 '
                'rounded-lg shadow-lg '
                'flex items-center gap-2'
            ).props('unelevated icon=arrow_back_ios').style('z-index: 1000;')

# Mostrar mascotas por tipo
@ui.page('/mascotas/{tipo}')
def mostrar_mascotas_por_tipo(tipo: str):
    """
    Página de listado de mascotas filtradas por tipo (especie).

    Esta vista muestra una grilla con todas las mascotas del veterinario actual,
    filtradas por la categoría seleccionada (por ejemplo: Caninos, Felinos, Aves).
    Cada mascota se representa con una tarjeta que incluye su información y botones
    para editar o eliminarla.

    Parámetros:
    - tipo (str): Nombre del tipo de mascota (caninos, felinos, etc.). Se utiliza
      para filtrar las mascotas mostradas.

    Funcionalidades:
    - Verifica si hay sesión activa del veterinario; de lo contrario, redirige al login.
    - Carga todas las mascotas del veterinario y filtra por categoría.
    - Muestra tarjetas con detalles de la mascota: nombre, raza, edad, sexo, peso, dueño, etc.
    - Permite editar los datos de la mascota mediante un diálogo.
    - Permite eliminar una mascota con confirmación visual.
    - Incluye un botón para volver a la pantalla de categorías.
    """
    #Contenedor y fondo
    with ui.element().classes('fixed inset-0 overflow-y-auto').style('''
        background-color: #5B80A0; height: 100vh;
    '''):
        #verifica que el vet este logueado
        session_veterinarian_id = app.storage.user.get('veterinarian_id')
        if not session_veterinarian_id:
            ui.notify('Debes iniciar sesión', type='warning')
            ui.run_javascript("window.location.href = '/'")
            return

        #carga y filtrado de mascotas
        mascotas = db.select_pet(session_veterinarian_id)
        mascotas_filtradas = [
            m for m in mascotas
            if Mascota.categorize_species(m.get('species', '')).lower() == tipo.lower()
        ]

        #titulo y grid de mascotas
        with ui.column().classes('items-center gap-6 w-full px-10 pt-10'):
            ui.label(f"Mascotas tipo: {tipo.capitalize()}").classes("text-3xl text-white")
            if not mascotas_filtradas:
                ui.label("No hay mascotas registradas de este tipo.").classes("text-white")
            else:
                with ui.element().classes(
                    "grid grid-cols-1 "
                    "sm:grid-cols-2 "
                    "md:grid-cols-4 "
                    "gap-8 "
                    "justify-items-center "
                    "w-full"
                ):
                    for m in mascotas_filtradas:
                        #contenido de cada card
                        with ui.card().style('''
                            background-color: #cce7ff;
                            color: #1e293b;
                            border-radius: 24px;
                            box-shadow: 0 4px 16px rgba(0,0,0,0.1);
                            width: 320px;
                            min-height: 420px;
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            padding: 2rem 1.5rem;
                        ''')as card:
                            # Foto circular arriba
                            if m.get('photo_url'):
                                ui.image(m['photo_url']).classes(
                                    "w-32 h-32 "
                                    "object-cover rounded-full "
                                    "border-4 border-white "
                                    "shadow-lg mb-4"
                                )
                            else:
                                ui.icon('pets').classes("text-7xl text-gray-400 mb-4")
                            # Nombre grande y centrado
                            ui.label(m['name']).classes("text-2xl font-bold text-center mb-2")
                            # Datos alineados tipo credencial
                            ui.label(f"Raza: {m['breed']}").classes("text-base text-center mb-1")
                            ui.label(f"Edad: {m['age']} años").classes("text-base text-center mb-1")
                            sexo = m.get('sexo')
                            ui.label(f"Sexo: {sexo.capitalize() if sexo else '-'}")\
                                .classes("text-base text-center mb-1")
                            peso = m.get('peso')
                            if peso is None:
                                peso = 0.0
                            elif isinstance(peso, str):
                                try:
                                    peso = float(peso)
                                except ValueError:
                                    peso = 0.0
                            ui.label(f"Peso: {peso} kg").classes("text-base text-center mb-1")
                            ui.label(f"Dueño: {m['owner_name']}")\
                                .classes("text-base text-center mb-1")
                            ui.label(f"Contacto: {m['owner_contact']}")\
                                .classes("text-base text-center mb-1")
                            if m['notes']:
                                ui.label(f"Notas: {m['notes']}")\
                                    .classes("text-sm text-center text-gray-500 mb-2")
                            # Botones de acción
                            with ui.row().classes('mt-4 justify-center gap-4'):
                                ui.button(icon='edit',
                                    on_click=lambda m=m: editar_mascota(m)
                                ).props('flat color=primary')
                                ui.button(icon='delete',
                                    on_click=lambda m=m, card=card: eliminar_mascota(m, card)
                                ).props('flat color=negative')

            # Botón "Volver" abajo a la derecha
            ui.button("Volver a Categorías",
                on_click=lambda: ui.run_javascript("window.location.href = '/mascotas';")
            ).classes(
                'fixed bottom-6 right-6 '
                'bg-gray-200 hover:bg-gray-300 '
                'text-gray-800 '
                'py-3 px-5 '
                'rounded-lg shadow-lg '
                'flex items-center gap-2'
            ).props('unelevated icon=arrow_back_ios').style('z-index: 1000;')

def editar_mascota(mascota):
    """
    Abre un diálogo modal que permite editar los datos de una mascota existente.

    Parámetros:
    mascota : dict
        Diccionario con los datos actuales de la mascota. Debe contener al menos
        las claves: 'id', 'name', 'breed', 'age', 'peso', y 'notes'.

    Funcionalidad:
    - Crea una ventana emergente con campos pre-rellenados de la mascota.
    - Permite modificar el nombre, raza, edad, peso y notas de la mascota.
    - Al presionar "Guardar", actualiza los datos en la base de datos mediante `db.update_pet`.
    - Muestra una notificación de éxito y recarga la página para reflejar los cambios.
    - También incluye un botón para cancelar la operación y cerrar el diálogo sin guardar.
    """
    with ui.dialog() as dialog, ui.card():
        ui.label(f"Editar mascota: {mascota['name']}").classes('text-xl font-bold')
        nombre = ui.input('Nombre', value=mascota['name'])
        raza = ui.input('Raza', value=mascota['breed'])
        edad = ui.number('Edad', value=mascota['age'])
        valor_peso = mascota.get('peso')
        try:
            valor_peso = float(valor_peso)
        except (TypeError, ValueError):
            valor_peso = 0.0

        peso = ui.number("Peso (kg):", value=valor_peso).props('outlined min=0 step=0.1')
        notas = ui.textarea('Notas', value=mascota['notes'] or '')

        def guardar():
            db.update_pet(mascota['id'], {
                'name': nombre.value,
                'breed': raza.value,
                'age': edad.value,
                'peso': peso.value,
                'notes': notas.value
            })
            ui.notify('Mascota actualizada correctamente')
            dialog.close()
            ui.run_javascript("window.location.reload()")

        ui.button('Guardar', on_click=guardar)
        ui.button('Cancelar', on_click=dialog.close)

    dialog.open()

def eliminar_mascota(mascota, card):
    """
    Muestra un cuadro de diálogo de confirmación para eliminar una mascota del sistema.

    Parámetros:
    mascota : dict
        Diccionario con los datos de la mascota a eliminar. Debe contener al menos
        las claves: 'id' y 'name'.

    card : ui.element
        Elemento de tarjeta (card) de la interfaz que representa visualmente a la mascota.
        Se eliminará de la interfaz si la operación es confirmada y exitosa.

    Funcionalidad:
    - Abre un diálogo de advertencia solicitando confirmación para eliminar la mascota.
    - Si el usuario confirma, llama a `db.delete_pet()` para eliminarla de la base de datos.
    - Elimina la tarjeta de la UI mediante `card.delete()` si la operación es exitosa.
    - Muestra una notificación de éxito o error según el resultado.
    - Permite cancelar la operación cerrando el diálogo sin modificar nada.
    """
    def confirmar_eliminar():
        try:
            db.delete_pet(mascota['id'])
            ui.notify(f"Mascota '{mascota['name']}' eliminada", color='negative')
            card.delete()  # Borra la tarjeta de la interfaz
            dialog.close()
        except APIError as err:
            ui.notify(f"❌ Error en la API al eliminar mascota: {err}", color='warning')
        except httpx.HTTPError as err:
            ui.notify(f"❌ Error de red al eliminar mascota: {err}", color='warning')

    with ui.dialog() as dialog, ui.card().style('''
        background-color: #2A2D3E; color: white;
    ''').classes('p-8 mx-auto'):
        # Icono centrado
        with ui.column().classes('items-center gap-6'):
            ui.icon('warning', color='orange').classes('text-4xl')

            # Mensaje principal en un recuadro centrado
            with ui.card().style('''
                background-color: #1C1C2E; border-left: 4px solid #ff6b6b;
            ''').classes('p-6 w-full'):
                ui.label(f"¿Confirmás eliminar a {mascota['name']}?")\
                    .classes('text-lg text-center w-full')

            # Botones centrados
            with ui.row().classes('justify-center gap-6 mt-4'):
                ui.button('CANCELAR',
                    on_click=dialog.close).props('flat color=white size=lg').classes('px-8')
                ui.button('ELIMINAR',
                    color='negative',
                    on_click=confirmar_eliminar).props('size=lg').classes('px-8')
    dialog.open()
