
from nicegui import ui

# ✅ PAGINA DE INCIO: dividida en:
    #INICIO
    #SOBRE NOSOTROS
    #CONTACTO

@ui.page('/')
def inicio():
    """
    Página principal de VetManager Peluchitos.
    Contiene el slider, encabezado, secciones informativas y pie de página.
    """
    ui.add_head_html('''
        <style>
            .slideshow-container {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                overflow: hidden;
                z-index: 0;
            }
            .slide { 
                position: absolute;
                width: 100%;
                height: 100%;
                background-size: cover;
                background-position: center;
                opacity: 0;
                transition: opacity 0.7s ease-in-out;
            }
            .slide.active {
                opacity: 1;
            }
            body {
                background-image: linear-gradient(rgba(0,0,0,0.1), rgba(0,0,0,0.1)),
                    url('https://img.freepik.com/vector-gratis/diseno-fondo-patron-huella-lindo-llamativo_1017-49663.jpg');
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed; /* para que quede fija al hacer scroll */
            }
        </style>
        <script>
            let slideIndex = 0;
            function showSlides() {
                const slides = document.querySelectorAll('.slide');
                slides.forEach((slide, i) => {
                    slide.classList.remove('active');
                    if (i === slideIndex) {
                        slide.classList.add('active');
                    }
                });
                slideIndex = (slideIndex + 1) % slides.length;
            }
            setInterval(showSlides, 3000);
            window.onload = showSlides;
        </script>
    ''')

    # 2. Cabecera (header) con título y botones de navegación --> menú superior
    with ui.header().classes(
        'px-6 py-4 flex justify-between items-center z-50 rounded-b-xl mx-4'
    ).style('background-color: rgba(70, 130, 180, 0.95); color: #1e293b;'):

        with ui.row().classes('items-center gap-4'):
            ui.label('🐾 VetManager Peluchitos').classes('text-2xl font-bold text-white')
            ui.label('Organizá tu veterinaria. Cuidá tus peluchitos')\
                .classes('text-lg italic text-white')

        with ui.row().classes('gap-6 items-center'):
            ui.button('Sobre Nosotros',
                on_click=lambda: ui.run_javascript(
                    "document.getElementById('sobre-nosotros')"
                    ".scrollIntoView({ behavior: 'smooth' });"
                )
            ).props('flat color=white').classes('text-lg text-white cursor-pointer')

            ui.button('Contactanos',
                on_click=lambda: ui.run_javascript(
                    "document.getElementById('contactanos').scrollIntoView({ behavior: 'smooth' });"
                )
            ).props('flat color=white').classes('text-lg text-white cursor-pointer')

            ui.button('Registrarse',
                    on_click=lambda: ui.run_javascript("window.location.href = '/register';")
            ).props('flat color=white').classes('text-lg px-5 py-2')

    # 3. Cuerpo dividido en dos columnas:
    with ui.row().classes('w-full h-screen'):

        # Izquierda: texto de bienvenida + texto descriptivo + botón
        with ui.column().classes('flex-grow h-full justify-center items-center p-8'):
            ui.label('Bienvenido a Peluchitos')\
                .classes('text-4xl font-bold text-gray-900 mb-6 text-center')

            mensaje_uno = (
                """
                En VetManager Peluchitos estamos comprometidos con quienes cuidan de los que
                más amamos. Sabemos que tu vocación va más allá del consultorio: es una mezcla
                de ciencia, empatía y amor por los animales. Por eso, desarrollamos una herramienta
                que simplifica tu trabajo diario, para que puedas concentrarte en lo que realmente
                importa: la salud y el bienestar de tus pacientes peludos. Transforma tu manera de
                trabajar con un software pensado por y para veterinarios.
                """
            )
            ui.label(mensaje_uno)\
                .classes('text-2xl text-gray-900 leading-relaxed text-center max-w-md mb-9')

            ui.button('Comenzar',
                on_click=lambda: ui.run_javascript("window.location.href = '/login';")
            ).props('color=primary').classes('text-lg px-6 py-3')

        # Derecha: slideshow con imágenes
        with ui.column().classes('w-1/2 h-full relative'):
            with ui.element('div').classes('slideshow-container h-full'):
                urls = [
                    "https://images.unsplash.com/photo-1558788353-f76d92427f16",
                    "https://images.unsplash.com/photo-1592194996308-7b43878e84a6",
                    "https://images.unsplash.com/photo-1563460716037-460a3ad24ba9"
                ]
                for url in urls:
                    ui.element('div').classes('slide h-full').style(
                        f'background-image: url("{url}");'
                        'background-size: cover;'
                        'background-position: center;'
                        'background-repeat: no-repeat;'
                    )

    # 4. Bloque “Lo que nos destaca”: tres cards con iconos y descripciones
    with ui.column()\
        .classes('max-w-8xl w-full mx-auto items-center py-16 px-8 bg-blue-100 rounded-2xl mx-4')\
            .style('min-height: 350px;'):
        ui.label('Lo que nos destaca')\
            .classes('text-4xl font-bold text-center mb-2 text-gray-900')

        mensaje_dos= (
            """
            Peluchitos ofrece un sistema simple y eficiente que contempla funcionalidades para la 
            administración de su veterinaria. Descubrí nuestros servicios pensados para vos y tus
            mascotas.
            """
        )
        ui.label(mensaje_dos).classes('text-lg text-center mb-8 text-gray-700 max-w-2xl')

        with ui.row().classes('justify-center gap-12 w-full max-w-5xl mx-auto'):
            # Característica 1
            with ui.column().classes('items-center w-72 rounded-xl p-6 shadow-md')\
                .style('background-color: #B0D0E9;'):
                ui.icon('pets')\
                    .classes('text-5xl text-sky-700 mb-3')
                ui.label('Registro de Mascotas')\
                    .classes('text-xl font-semibold mb-1 text-gray-900')
                ui.label(
                    (
                        'Almacená los datos importantes, contacto'
                        'del dueño y foto de cada mascota fácilmente.'
                    )
                ).classes('text-center text-gray-700')

            # Característica 2
            with ui.column().classes('items-center w-72 rounded-xl p-6 shadow-md')\
                .style('background-color: #B0D0E9;'):
                ui.icon('badge').classes('text-5xl text-sky-700 mb-3')
                ui.label('Credencial de Mascotas')\
                    .classes('text-xl font-semibold mb-1 text-gray-900')
                ui.label(
                    (
                        'Fichas con foto, especie y datos esenciales' 
                        'para identificar a cada peluchito fácilmente.'
                    )
                ).classes('text-center text-gray-700')

            # Característica 3
            with ui.column().classes('items-center w-72 rounded-xl p-6 shadow-md')\
                .style('background-color: #B0D0E9;'):
                ui.icon('event_available').classes('text-5xl text-sky-700 mb-3')
                ui.label('Gestión de Turnos').classes('text-xl font-semibold mb-1 text-gray-900')
                ui.label(
                    (
                        'Seleccioná al paciente, definí el horario' 
                        'y visualizalo directamente en tu agenda.'
                    )
                ).classes('text-center text-gray-700')

    # 5. Sección “¿Por qué usar un software veterinario?”
    with ui.column()\
        .classes('max-w-8xl w-full mx-auto py-16 bg-blue-100 items-center rounded-2xl mx-4')\
            .style(
                'background-size: cover;' 
                'background-position: center;'
                'background-repeat: no-repeat;'
            ):
        ui.label('¿Por qué usar un software veterinario?')\
            .classes('text-4xl font-bold text-center mb-4 text-gray-900')

        mensaje_tres= (
            """
            En un entorno donde el tiempo y la eficiencia son clave, un software de gestión
            veterinaria como VetManager Peluchitos se convierte en una herramienta esencial
            para profesionales del cuidado animal.
            Esta solución digital permite organizar turnos, gestionar las mascotas y los
            propios tiempos de cada veterinario desde un solo lugar, facilitando el
            trabajo diario y optimizando los recursos.
            """
        )
        ui.label(mensaje_tres).classes('text-lg text-center max-w-4xl text-gray-700')

        mensaje_cuatro= (
            """
            Con Peluchitos, los veterinarios pueden dedicar más tiempo a lo que realmente
            importa: el bienestar de sus pacientes, ofreciendo una atención personalizada,
            rápida y sin complicaciones.
            El sistema se adapta a las necesidades de cada profesional, brindando un entorno
            intuitivo y eficiente.
            """
        )
        ui.label(mensaje_cuatro).classes('text-lg text-center max-w-4xl text-gray-700')

    # 6. Sección Manual de Uso en Video
    with ui.column()\
        .classes('max-w-8xl w-full mx-auto py-16 bg-blue-100 items-center rounded-2xl mx-4')\
            .style(
                'background-size: cover;' 
                'background-position: center;'
                'background-repeat: no-repeat;'
            ):
        ui.label('Manual de Uso - ¿Cómo funciona?')\
            .classes('text-4xl font-bold text-center mb-6 text-gray-900')
        ui.html('''
            <div style="text-align: center;">
                <iframe width="560" height="315"
                    src="https://www.youtube.com/embed/N_orCotGLes"
                    title="Manual de Uso VetManager Peluchitos"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                    style="border-radius: 1rem;">
                </iframe>
            </div>
        ''')

    # 7. Sección SOBRE NOSOTROS
    with ui.column()\
        .classes('max-w-8xl w-full mx-auto py-16 bg-blue-100 items-center rounded-2xl mx-4')\
            .style(
                'background-size: cover;' 
                'background-position: center;'
                'background-repeat: no-repeat;'
            ).props('id=sobre-nosotros'):
        ui.label('Sobre Nosotros')\
            .classes('text-4xl font-bold text-center mb-4 text-gray-900')

        mensaje_cinco = (
            """
            En VetManager Peluchitos creemos que la tecnología puede ser una gran aliada
            para quienes dedican su vida a cuidar a los animales.

            Somos un equipo de profesionales apasionados por la informática y el mundo
            veterinario, que decidimos unir ambos mundos para crear una herramienta
            diseñada exclusivamente para profesionales veterinarios.

            Conocemos los desafíos que enfrentan día a día: agendas cargadas, fichas
            médicas en papel, seguimiento de pacientes, gestión de turnos… Por eso
            desarrollamos un software simple, intuitivo y amigable, que te permite
            tener todo organizado desde un mismo lugar. 

            Nuestro objetivo es claro: facilitar tu trabajo para que puedas enfocarte
            en lo que realmente importa - el bienestar de tus pacientes peludos.
            """
        )
        ui.label(mensaje_cinco).classes('text-lg text-center max-w-2xl leading-relaxed')
    # 8. Sección Contactanos
    with ui.column()\
        .classes('max-w-8xl w-full mx-auto py-16 bg-blue-100 items-center rounded-2xl mx-4')\
            .style(
                'background-size: cover;' 
                'background-position: center;'
                'background-repeat: no-repeat;'
            ).props('id=contactanos'):
        ui.label('¡No esperes más! Contactanos ;)')\
            .classes('text-4xl font-bold text-center mb-4 text-gray-900')
        ui.html('''
                <form action="https://formsubmit.co/tu_correo@gmail.com" method="POST" 
                    style="max-width:600px; width:100%; background-color: rgba(70, 130, 180, 0.15); padding: 2rem; border-radius: 1rem; font-family: Arial, sans-serif;">
                    <input type="hidden" name="_captcha" value="false">
                    <input type="email" name="email" placeholder="Correo electrónico" required 
                        style="width: 100%; padding: 0.75rem; margin: 0.5rem 0; border-radius: 0.5rem; border: none; font-size: 1rem; background-color: #f9f9f9;">
                    <input type="text" name="nombre" placeholder="Nombre completo" required 
                        style="width: 100%; padding: 0.75rem; margin: 0.5rem 0; border-radius: 0.5rem; border: none; font-size: 1rem; background-color: #f9f9f9;">
                    <input type="text" name="telefono" placeholder="Teléfono de contacto" 
                        style="width: 100%; padding: 0.75rem; margin: 0.5rem 0; border-radius: 0.5rem; border: none; font-size: 1rem; background-color: #f9f9f9;">
                    <textarea name="mensaje" placeholder="Mensaje" rows="5" required 
                            style="width: 100%; padding: 0.75rem; margin: 0.5rem 0; border-radius: 0.5rem; border: none; font-size: 1rem; background-color: #f9f9f9;"></textarea>
                    <button type="submit" 
                            style="width: 100%; padding: 0.75rem; margin: 0.5rem 0; border-radius: 0.5rem; background-color: #007bff; color: white; font-weight: bold; cursor: pointer; transition: background-color 0.3s ease;"
                            onmouseover="this.style.backgroundColor='#0056b3';"
                            onmouseout="this.style.backgroundColor='#007bff';"
                    >Enviar</button>
                </form>
        ''')

    # 9. Pie de página (footer) con dirección, redes y derechos
    with ui.footer().classes(
        'absolute text-white py-8 px-6 rounded-b-xl mx-4'
    ).style('background-color: rgba(70, 130, 180, 0.95); color: #1e293b;'):

        with ui.row().classes('w-full justify-between items-center'):
        # Columna izquierda: contacto
            with ui.column().classes('gap-2'):
                ui.label('📍 Dirección: Av. Callao 123, Buenos Aires')
                ui.label('📞 Teléfono: +54 9 11 500 9780')
                ui.label('✉️ Email: veterinariapeluchitos@gmail.com')
        # Columna central: redes
        with ui.column().classes('gap-2 items-center'):
            ui.label('🌐 Seguinos en nuestras redes:')
            ui.label('Instagram | Facebook | TikTok')
        # Columna derecha: derechos
        with ui.column().classes('gap-2 items-end'):
            ui.label('© 2025 Peluchitos')
            ui.label('Todos los derechos reservados.')
