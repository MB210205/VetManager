from nicegui import app, ui
from controladores.logica_login import validar_login, autenticar_veterinario
from modelos.dbbroker import SupabaseBroker
from vistas.administradorPerfil import AdministradorPerfil

db = SupabaseBroker()
admin = AdministradorPerfil(db)

# ✅ LOGIN
@ui.page('/login')
def login():
    """
    Página de inicio de sesión para veterinarios en VetManager Peluchitos.
    Presenta un formulario para ingresar correo electrónico y contraseña,
    valida los datos y realiza la autenticación.
    """

    ui.add_head_html('''
        <style>
            html, body {
                margin: 0;
                padding: 0;
                height: 100%;
                font-family: 'Poiret One', sans-serif;
                background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                            url('https://img.freepik.com/vector-premium/ilustracion-vectorial-patron-costuras-pata-gato-huella-pata-gato-aislada-sobre-fondo-blanco_478768-259.jpg?w=2000');
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                overflow: hidden;
            }
            .titulo-vet {
                top: 20px;
                left: 20px;
                color: #1e293b;
                font-size: 80px;
                font-weight: bold;
                font-family: 'Playfair Display', serif;
                user-select: none; 
                cursor: default;
                margin-bottom: 30px; /* Espacio debajo del título */
                text-align: center;
            }
            .custom-input input {
                color: #1e293b;
            }
        </style>
    ''')
#__
    # Menú superior: header "volver", que redirige a /principal
    with ui.row().classes('fixed top-4 right-4'):
        ui.button("Volver al Panel",
                        on_click=lambda: ui.run_javascript("window.location.href = '/';")
                ).classes(
                    'fixed bottom-6 right-6 '
                    'bg-gray-200 hover:bg-gray-300 '
                    'text-gray-800 py-3 px-5 '
                    'rounded-lg shadow-lg '
                    'flex items-center gap-2'
                ).props('unelevated icon=arrow_back_ios').style('z-index: 1000;')

    #CONTENEDOR CENTRAL: FORMULARIO
    with ui.column().style('''
        width: 100vw;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    '''):
       #card del formulario
        with ui.card().classes('p-10 shadow-xl').style(
            'width: 550px; background-color: #ffffff; border-radius: 24px; color: #334155;'
        ):
            ui.label('🐾 Peluchitos').classes('titulo-vet')
            ui.label('Iniciar Sesión').classes('titulo-animado text-4xl mb-8')

            #Campo email
            with ui.row().classes('w-full mb-6').style('position: relative; align-items: center;'):
                ui.icon('email').style('''
                    position: absolute;
                    left: 12px;
                    color: #1e293b;
                    font-size: 24px;
                ''')
                email = ui.input()\
                    .props('outlined dense type=email clearable')\
                        .classes('w-full custom-input')
                email.props('placeholder="Correo electrónico"')
                email.style('padding-left: 50px; font-size: 18px; height: 50px;')

            #campo contraseña
            with ui.row().classes('w-full mb-8').style('position: relative; align-items: center;'):
                ui.icon('lock').style('''
                    position: absolute;
                    left: 12px;
                    color: #1e293b;
                    font-size: 24px;
                ''')
                password = ui.input()\
                    .props('outlined dense type=password clearable')\
                        .classes('w-full custom-input')
                password.props('placeholder="Contraseña"')
                password.style('padding-left: 50px; font-size: 18px; height: 50px;')

            def iniciar():
                # Validación básica
                valido, mensaje = validar_login(email.value, password.value)
                if not valido:
                    ui.notify(mensaje, type='warning')
                    return

                # Autenticación
                ok, resultado, mensaje = autenticar_veterinario(
                    admin, db, email.value, password.value
                )
                tipo = 'positive' if ok else 'negative'
                ui.notify(mensaje, type=tipo)

                if ok:
                    veterinarian_id, nombre = resultado  # ✅ desempaquetar correctamente la tupla
                    app.storage.user['veterinarian_id'] = veterinarian_id
                    app.storage.user['nombre'] = nombre
                    ui.run_javascript("window.location.href = '/principal';")

            #Boton de envio
            ui.button('INICIAR SESIÓN', on_click=iniciar)\
                .props('color=primary unelevated')\
                    .classes('w-full font-semibold')\
                        .style('font-size: 20px; height: 52px; border-radius: 10px;')

            #Enlace a pagina de recuperacion de contraseña
            ui.link("¿Olvidaste tu contraseña?", "/recuperar")\
                .classes("text-blue-700 hover:underline mt-2")

            #Enlace al registro
            ui.html('''
                <p style="color: #ccc; text-align: center; margin-top: 1.5rem; font-size: 1.1rem;">
                    ¿No tienes cuenta?
                    <a href="/register" style="color: #42a5f5; text-decoration: none; font-weight: 700;">Regístrate aquí</a>
                </p>
            ''')