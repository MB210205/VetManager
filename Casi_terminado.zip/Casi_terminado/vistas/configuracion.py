from nicegui import ui, app
from modelos.dbbroker import SupabaseBroker
from modelos.veterinario import Veterinario #clase para cargar datos del veterinario en sesión.
from controladores.logica_configuracion import guardar_datos_perfil, subir_imagen_y_guardar
from vistas.administradorPerfil import AdministradorPerfil




db = SupabaseBroker()
admin = AdministradorPerfil(db)


# ✅ CONFIGURACIÓN
@ui.page('/configuracion')
def configuracion():
    """
    Página de configuración del perfil del veterinario.

    Esta función permite al veterinario:
    - Ver y modificar su nombre y correo electrónico
    - Subir una nueva foto de perfil (guardada en Supabase Storage)
    - Guardar los cambios en la base de datos
    - Cambiar su contraseña
    - Cerrar sesión
    - Volver al panel principal

    Si no hay sesión activa, redirige a la página de inicio de sesión.
    """
    #Recupera el veterinarian_id de la sesion almacenada
    session_veterinarian_id = app.storage.user.get('veterinarian_id')
    if not session_veterinarian_id:
        ui.notify('Debes iniciar sesión', type='warning')
        ui.run_javascript("window.location.href = '/'")
        return

    #Carga datos del veterinario
    veterinario = Veterinario(email=None)
    veterinario.cargar_por_id(db, session_veterinarian_id)

    perfil_path = {'url': veterinario.profile_imagen}

    def handle_profile_upload(e, perfil_path):
        """
        Handler para subir la imagen al bucket "veterinarios",
        obtener su URL pública y guardarla en la columna profile_imagen.
        """
        veterinarian_id = app.storage.user.get('veterinarian_id')
        exito, resultado = subir_imagen_y_guardar(db, e, veterinarian_id)
        if exito:
            perfil_path['url'] = resultado
            ui.notify('✅ Imagen subida correctamente', type='positive')
        else:
            ui.notify(resultado, type='negative')

    ui.add_head_html('''
        <style>
            html, body {
                margin: 0;
                padding: 0;
                border: 0;
                width: 100vw;
                height: 100vh;
                font-family: 'Poiret One', sans-serif;
                background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                            url('https://img.freepik.com/vector-gratis/clinica-veterinaria-medico-mascotas-enfermas_107791-11715.jpg?t=st=1752273096~exp=1752276696~hmac=1d25a1c73421f59c5ab286513edd3a72f0044284504d033087a5ad8403c40457&w=2000')
                            no-repeat center center fixed;
                background-size: cover;
                overflow: hidden;
            }

            .titulo-vet {
                position: fixed;
                top: 20px;
                left: 20px;
                color: #e0e0e0;
                font-size: 80px;
                font-weight: bold;
                font-family: 'Playfair Display', serif;
                user-select: none; 
                cursor: default;
            }
            /* INPUT: texto ingresado */
            .q-field__native,
            .q-field__input {
                color: #000 !important;
            }
            textarea {
                resize: none !important;  /* ❌ evita que pueda agrandarse */
            }
            
            .scrollable-form::-webkit-scrollbar {
                width: 8px;
            }
            .scrollable-form::-webkit-scrollbar-thumb {
                background-color: #ccc;
                border-radius: 8px;
            }
            .scrollable-form {
                scrollbar-width: thin;
                scrollbar-color: #ccc transparent;
            }

            .q-field_native, .q-field_input {
                color: #000 !important;
            }
        </style>
    ''')

    # Fila superior: Título a la izquierda, perfil a la derecha (cabecera fija)
    with ui.row().classes(
        'w-full items-center justify-between px-8 py-2 shadow-md backdrop-blur-md' \
    '').style('''
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background-color: rgba(255, 255, 255, 0.7);
        '''):

        ui.label('🐾 Peluchitos').classes('titulo-vet') \
        .style('''
                position: static; 
                font-size: 80px; 
                font-weight: bold; 
                color: #1e293b; 
                font-family: "Playfair Display", serif; 
                margin-left: 40px;
            ''')
        ui.label('Configuración').classes('text-h4 text-center').style('''
            color: #1e293b; font-family: "Playfair Display", serif; font-size: 40px
        ''')

    #ESTRUCTURA PRINCIPAL: Formulario de configuración
    with ui.column().style('''
        width: 100vw;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        padding-top: 160px;
        padding-bottom: 40px;
    '''):
        # --- CARD SCROLLABLE ---
        with ui.element().style('''
            width: 550px;
            max-height: 90vh;
            overflow-y: auto;
            background-color: #ffffff;
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.2);
            color: #334155;
        ''').classes('scrollable-form'):

            with ui.row().classes('justify-center'):
            # 1) Previsualización de la foto actual o placeholder
                if perfil_path['url']:
                    ui.image(perfil_path['url']).classes('w-32 h-32 rounded-full mb-4')
                else:
                    ui.icon('account_circle').classes('text-7xl text-gray-400 mb-4')

            # — NUEVO—
            ui.input(
                'Matrícula',
                value=veterinario.matricula or '-'
            ).props('outlined dense readonly') \
             .classes('w-full mb-6 bg-transparent shadow-none') \
             .style('''
                background-color: #F5F5F5;
                color: #000000;
                font-size: 16px;
                height: 48px;
                padding-left: 12px;
             ''')

            # 2) Componente de upload
            ui.upload(
                label='Cambiar foto de perfil',
                auto_upload=True,
                on_upload=lambda e: handle_profile_upload(e, perfil_path)
            ).props('accept="image/*"').classes('w-full mb-6')

            # 3) Campo nombre (editable)
            nombre = ui.input(
                'Nombre completo',
                value=veterinario.nombre
            ).props('outlined dense clearable') \
                .classes('w-full mb-4 bg-transparent shadow-none') \
                    .style('''
                        background-color: #F5F5F5;
                        color: black;
                        font-size: 16px;
                        height: 48px;
                        padding-left: 12px;
                    ''')
            # 4) Campo email (editable también)
            email = ui.input(
                'Correo electrónico',
                value=veterinario.email
            ).props('outlined dense clearable type=email') \
                .classes('w-full mb-4 bg-transparent shadow-none') \
                    .style('''
                        background-color: #F5F5F5;
                        color: black;           
                        font-size: 16px;
                        height: 48px;
                        padding-left: 12px;
                    ''')

            # 5) Campo genero
            genero = ui.input(
                'genero',
                value=veterinario.genero or ''
            ).props('outlined dense clearable') \
                .classes('w-full mb-4 bg-transparent shadow-none')\
                    .style('''
                        background-color: #F5F5F5;
                        color: black;           
                        font-size: 16px;
                        min-height: 48px;
                        padding-left: 12px;
                        resize: none;
                    ''')

            # 5) Campo telefono
            telefono = ui.input(
                'Teléfono',
                value=veterinario.phone_number or ''
            ).props('outlined dense clearable type=tel') \
                .classes('w-full mb-4 bg-transparent shadow-none')\
                    .style('''
                        background-color: #F5F5F5;
                        color: black;           
                        font-size: 16px;
                        height: 48px;
                        padding-left: 12px;
                    ''')

            # 5) Campo Edad
            edad = ui.number(
                'Edad',
                value=veterinario.age or 0,
                min=0, max=120
            ).props('outlined dense clearable')\
                .classes('w-full mb-4 bg-transparent shadow-none')\
                    .style('''
                        background-color: #F5F5F5;
                        color: black;           
                        font-size: 16px;
                        height: 48px;
                        padding-left: 12px;
                    ''')

            # 5) Campo Dirección
            direccion = ui.input(
                'Dirección',
                value=veterinario.address or ''
            ).props('outlined dense clearable')\
                .classes('w-full mb-4 bg-transparent shadow-none')\
                    .style('''
                        background-color: #F5F5F5;
                        color: black;           
                        font-size: 16px;
                        min-height: 48px;
                        padding-left: 12px;
                        resize: none;
                    ''')

            # Lógica para guardar cambios
            def guardar_cambios():
                cambios = {}
                if nombre.value.strip():
                    cambios['name'] = nombre.value.strip()
                if email.value.strip():
                    cambios['email'] = email.value.strip()
                if genero.value:
                    cambios['genero'] = genero.value
                if telefono.value.strip():
                    cambios['phone_number'] = telefono.value.strip()
                if edad.value is not None:
                    try:
                        cambios['age'] = int(edad.value)
                    except (ValueError, TypeError):
                        ui.notify('⚠️ La edad debe ser un número entero', type='warning')
                        return
                if direccion.value.strip():
                    cambios['address'] = direccion.value.strip()
                if perfil_path.get('url'):
                    cambios['profile_imagen'] = perfil_path['url']

                exito, mensaje = guardar_datos_perfil(db, session_veterinarian_id, cambios)
                if exito:
                    ui.notify(mensaje, type='positive', timeout=3000)
                    ui.timer(2.0,
                            lambda: ui.run_javascript("window.location.href = '/principal';"),
                            once=True)
                else:
                    ui.notify(mensaje, type='negative')
            # Botones
            with ui.row().classes('w-full justify-between mt-6'):
                # Botón "Guardar Cambios"
                ui.button("Guardar Cambios", on_click=guardar_cambios)\
                    .props('color=primary outline').style('''
                        font-size: 15px; height: 40px; border-radius: 5px;
                    ''')
                # Botón "Cambiar contraseña"
                ui.button("Cambiar contraseña",
                    on_click=lambda: ui.run_javascript("window.location.href = '/recuperar';")
                ).props('color=warning outline')

        # --- FIN DEL CARD ---
        # Botón "Cerrar sesión" abajo a la izquierda
        ui.button(
            "CERRAR SESIÓN",
            on_click=lambda: (
                admin.cerrar_sesion(),
                app.storage.user.clear(),
                ui.run_javascript("window.location.href = '/login';")
            )
        ).classes(
            'fixed bottom-6 left-6 '
            'bg-red-600 hover:bg-red-700 '
            'text-white py-3 px-5 '
            'rounded-lg shadow-lg'
        ).props('unelevated').style('z-index: 1000;')

        # Botón "Volver" abajo a la derecha
        ui.button("Volver al Panel",
                on_click=lambda: ui.run_javascript("window.location.href = '/principal';")
        ).classes(
            'fixed bottom-6 right-6 '
            'bg-gray-200 hover:bg-gray-300 '
            'text-gray-800 py-3 px-5 '
            'rounded-lg shadow-lg '
            'flex items-center gap-2'
        ).props('unelevated icon=arrow_back_ios').style('z-index: 1000;')