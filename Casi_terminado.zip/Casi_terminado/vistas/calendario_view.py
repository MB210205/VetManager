from datetime import date, datetime
from nicegui import ui, app #el framework NiceGUI para construir la interfaz web.
from modelos.dbbroker import SupabaseBroker
from modelos.veterinario import Veterinario

from vistas.encuesta import Encuesta
from vistas.administradorPerfil import AdministradorPerfil
from modelos.calendario import Calendario

from controladores.logica_calendario import analizar_estado_dia, eliminar_cita_por_id, generar_eventos, guardar_nueva_mascota, obtener_citas_del_dia, obtener_estadisticas, obtener_estado_dias, subir_imagen_mascota, validar_campos_mascota, validar_y_agendar


db = SupabaseBroker()
admin = AdministradorPerfil(db)
encuesta = Encuesta()  # usa sqlite:///jobs.sqlite por defecto

# verifica sesion activa

#Cargamos el veterinario (¡antes de usarlo en la UI!)
veterinario = Veterinario(email=None)


# ✅ CALENDARIO
@ui.page('/calendario')
def mostrar_calendario():
    """
    Muestra y gestiona el calendario de citas veterinarias para un veterinario logueado.

    Esta función crea la interfaz gráfica para visualizar, agregar, eliminar y listar
    citas veterinarias mediante un calendario y una lista asociada al día seleccionado.
    También permite agregar nuevas mascotas con su respectiva información y foto.

    Funcionalidades principales:
    - Visualización de un calendario con estilos dinámicos según la cantidad de turnos.
    - Filtrado de citas por fecha seleccionada.
    - Agregar, eliminar y listar citas con validación de campos.
    - Agregar nuevas mascotas con subida de imagen a almacenamiento remoto.
    - Control de disponibilidad y notificación de estados (libre, ocupado, completo).
    - Actualización dinámica de la interfaz y notificaciones al usuario.
    - Gestión de datos persistentes mediante conexión a base de datos y almacenamiento.
    - Botones y diálogos con confirmaciones para operaciones críticas.
    """
    # verifica sesion activa
    session_veterinarian_id = app.storage.user.get('veterinarian_id')
    if not session_veterinarian_id:
        ui.notify('Debes iniciar sesión', type='warning')
        ui.run_javascript("window.location.href = '/'")
        return

    calendario_local = Calendario(db, session_veterinarian_id)

    total_mascotas, total_citas_futuras, total_citas_hoy = obtener_estadisticas(session_veterinarian_id, db, calendario_local.obtener_citas())

    veterinario = Veterinario(email=None)
    veterinario.cargar_por_id(db, session_veterinarian_id)
    foto_url = getattr(veterinario, 'profile_imagen', None)

    # 1) Traigo todas las mascotas
    mascotas = db.select_pet(session_veterinarian_id)

    # 2) Creo la lista sólo de nombres
    nombres_mascotas = [ m["name"] for m in mascotas ]

    # 3) Map de nombre → id
    id_por_nombre = { m["name"]: m["id"] for m in mascotas }

    mascota_select = ui.select(
        options = nombres_mascotas,
        label = "Selecciona Mascota")\
            .props('outlined clearable')\
                .style("width:100%; margin-bottom:1rem;")

    #estilos
    ui.add_head_html('''
        <style>
            html, body {
                margin: 0;
                padding: 0;
                width: 100vw;
                height: 100vh;
                overflow: hidden;
                font-family: 'Poiret One', sans-serif;
                background-image: url("https://img.freepik.com/vector-gratis/diseno-fondo-patron-huella-lindo-llamativo_1017-49663.jpg?t=st=1752273497~exp=1752277097~hmac=d7091a438a367c5ad85a49bc3d7f1723a0400880cd71f5ff2466efd641eff5fa&w=2000");
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                overflow-y: auto;
            }
            .titulo-vet {
                color: #1e293b; /* gris oscuro azulado */
                position: fixed;
                top: 20px;
                left: 20px;
                font-size: 80px;
                font-weight: bold;
                font-family: 'Playfair Display', serif;
                user-select: none; 
                cursor: default;
            }
            .custom-input input,
            .custom-input textarea,
            .custom-input select {
                color: #1e293b !important;
            }
            .q-field__label,
            label,
            .q-field__native {
                color: #1e293b !important;
            }
            ::placeholder { 
                color: #1e293b !important;
                opacity: 1; 
            }
            .fab-mascota {
                position: fixed;
                bottom: 40px;
                right: 40px;
                width: 70px;
                height: 70px;
                border-radius: 50%;
                background: #1e293b;
                color: white;
                font-size: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 4px 16px rgba(0,0,0,0.2);
                cursor: pointer;
                z-index: 1000;
                transition: background 0.2s;
            }
            .fab-mascota:hover {
                background: white;
            }
            .q-date {
                background: white !important;
                color: #1e293b !important;
                border-radius: 16px !important;
            }
            .q-date__header {
                background: white !important;
                color: #1e293b !important;
                border-radius: 16px 16px 0 0 !important;
            }
            .q-table {
                background: white !important;
                color: #1e293b !important;
                border-radius: 12px !important;
            }
            .q-table__container td,
            .q-table__container th {
                background: white !important;
                color: #1e293b !important;
            }
            /* Oculta el mensaje "No data available" de la tabla */
            .q-table__bottom--nodata,
            .q-table__bottom .q-table__bottom-nodata,
            .q-table__bottom-nodata {
                display: none !important;
            }
            
            .contenedor-principal {
                background-color: transparent !important; /* que no pinte violeta */
                min-height: 100vh; width: 100vw;
                display: flex; flex-direction: column;
            }
            
            .header-container {
                width: 100%;
                padding: 20px 40px;
                margin-bottom: 40px;
                box-sizing: border-box;
            }
            
            .content-row {
                display: flex;
                gap: 3rem;
                align-items: flex-start;
                justify-content: center;
                flex-wrap: wrap;
                width: 100%;
                padding: 0 20px;
                box-sizing: border-box;
            }
            
            .form-column {
                flex: 0 0 auto;
                max-width: 450px;
                min-width: 500px;
            }
            
            .calendar-column {
                flex: 0 0 auto;
                max-width: 700px;
                min-width: 500px;
            }
                     
            /* Responsive adjustments */
            @media (max-width: 1400px) {
                .content-row {
                    flex-direction: column;
                    align-items: center;
                }
                .titulo-vet {
                    font-size: 60px;
                }
            }
            
            @media (max-width: 768px) {
                .titulo-vet {
                    font-size: 40px;
                }
                .form-column, .calendar-column {
                    min-width: 90%;
                    max-width: 90%;
                }
            }
            
            /* NUEVOS ESTILOS PARA LEYENDA Y DÍAS CON TURNOS */
            /* Estilos para días con turnos completos */
            .q-date__calendar-item--in .q-btn__content::after {
                content: '';
                position: absolute;
                bottom: 2px;
                left: 50%;
                transform: translateX(-50%);
                width: 4px;
                height: 4px;
                border-radius: 50%;
            }
            
            /* Día con pocos turnos - punto verde */
            .dia-disponible .q-btn__content::after {
                background: #4CAF50 !important;
            }
            
            /* Día con muchos turnos - punto naranja */
            .dia-ocupado .q-btn__content::after {
                background: #FF9800 !important;
            }
            
            /* Día completamente lleno - punto rojo */
            .dia-completo .q-btn__content::after {
                background: #F44336 !important;
            }
            
            /* Cambiar color de fondo para días completos */
            .dia-completo .q-btn {
                background: rgba(244, 67, 54, 0.2) !important;
                color: #fff !important;
            }
            
            .dia-ocupado .q-btn {
                background: rgba(255, 152, 0, 0.2) !important;
                color: #fff !important;
            }
        </style>
    ''')

    with ui.row().classes(
        'w-full items-center justify-between px-8 py-4 shadow-md backdrop-blur-md')\
            .style('''
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                z-index: 1000;
                background-color: rgba(255, 255, 255, 0.7);
            '''):
        ui.label('🐾 Peluchitos').classes('titulo-vet') \
        .style('''
                position: static; 
                font-size: 80px; 
                font-weight: bold; 
                color: #1e293b; 
                font-family: "Playfair Display", serif; 
                margin-left: 40px;
            ''')
        ui.label('Agenda de Citas').classes('text-h4 text-center')\
            .style('color: #1e293b; font-family: "Playfair Display", serif; font-size: 40px')

        with ui.row().classes('items-center gap-4').style('margin-right: 40px;'):
            foto_url = getattr(veterinario, 'profile_imagen', None)
            if foto_url:
                # mostramos la imagen subida, ahora más grande
                ui.image(foto_url) \
                .classes('w-16 h-16 md:w-20 md:h-20 rounded-full cursor-pointer') \
                .on('click', lambda: ui.run_javascript("window.location.href = '/configuracion';"))
            else:
                # icono por defecto
                ui.button(icon='account_circle',
                    on_click=lambda: ui.run_javascript("window.location.href = '/configuracion';")
                ).props('flat round color=white size=xl')

    def aplicar_estilos_calendario():
        """Aplica estilos CSS a los días del calendario según su estado"""
        citas = calendario_local.obtener_citas()  # Obtén las citas primero
        estados = obtener_estado_dias(citas)      # Pásalas a la función

        # JavaScript para aplicar clases CSS a los días
        js_code = """
        setTimeout(() => {
            // Limpiar clases previas
            document.querySelectorAll('.q-date__calendar-item').forEach(item => {
                item.classList.remove('dia-disponible', 'dia-ocupado', 'dia-completo');
            });
            
            // Aplicar nuevas clases
        """

        for fecha, estado in estados.items():
            #  parsear sólo YYYY-MM-DD; saltamos si no encaja
            try:
                fecha_dt = datetime.strptime(fecha, "%Y-%m-%d")
            except ValueError:
                continue

            dia = str(fecha_dt.day)  # día sin cero a la izquierda
            js_code += (
                f"const elemento_{dia} = document.querySelector("
                f"'.q-date__calendar-item[data-n=\"{dia}\"]');\n"
                f"if (elemento_{dia}) {{\n"
                f"    elemento_{dia}.classList.add('dia-{estado}');\n"
                f"}}\n"
            )

        js_code += """
        }, 500);
        """

        ui.run_javascript(js_code)

    # Obtenemos estadísticas: LOGICA EN logica_calendario en obtener_estadisticas()
    with ui.row().classes('justify-center items-stretch gap-6 mb-8')\
        .style("flex-wrap: wrap; width: 100%; padding-top: 210px;"):
        # Card de mascotas
        with ui.card().style('''
            background: #d0e8ff;
            color: #1e293b;
            width: 200px;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        '''):
            with ui.row().classes('items-center gap-2'):
                ui.icon('pets').style('font-size: 28px; color: #2563eb;')  # azul medio
                ui.label('Mascotas').classes('text-lg font-medium mb-2')
            ui.label(str(total_mascotas)).classes('text-3xl font-bold')

        # Card de turnos futuros
        with ui.card().style('''
            background: #a5d8ff;
            color: #1e293b;
            width: 200px;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        '''):
            with ui.row().classes('items-center gap-2'):
                ui.icon('calendar_today')\
                    .style('font-size: 28px; color: #1e40af;')  # azul más oscuro
                ui.label('Turnos futuros').classes('text-lg font-medium mb-2')
            ui.label(str(total_citas_futuras)).classes('text-3xl font-bold')

        # Card de hoy
        with ui.card().style('''
            background: #7ec0ff;
            color: #1e293b;
            width: 200px;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        '''):
            with ui.row().classes('items-center gap-2'):
                ui.icon('access_time').style('font-size: 28px; color: #1e3a8a;')  # azul oscuro
                ui.label('Hoy').classes('text-lg font-medium mb-2')
            ui.label(str(total_citas_hoy)).classes('text-3xl font-bold')

        #Card de leyenda
        with ui.card().style('''
            background: #f9fafb;
            padding: 1rem;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        '''):
            ui.label("Leyenda del Calendario").style('''
                color: #1e293b; font-weight: bold; font-size: 16px; margin-bottom: 0.75rem;
            ''')
            with ui.row().classes("items-center gap-2"):
                ui.element().style('''
                    width: 12px; height: 12px; background: #4CAF50; border-radius: 50%;
                ''')
                ui.label("Día disponible").style("color: #1e293b; font-size: 12px;")
            with ui.row().classes("items-center gap-2"):
                ui.element().style('''
                    width: 12px; height: 12px; background: #FF9800; border-radius: 50%;
                ''')
                ui.label("Día ocupado").style("color: #1e293b; font-size: 12px;")
            with ui.row().classes("items-center gap-2"):
                ui.element().style('''
                    width: 12px; height: 12px; background: #F44336; border-radius: 50%;
                ''')
                ui.label("Día completo").style("color: #1e293b; font-size: 12px;")

    # CONTENEDOR PRINCIPAL SIN POSITION FIXED
    with ui.element().classes('contenedor-principal').style('background-color: #1C1C2E'):
        # CONTENIDO PRINCIPAL CON FLEXBOX MEJORADO
        with ui.element().classes("content-row"):

            # Columna izquierda: Formulario
            with ui.element().classes("form-column"):
                with ui.card().style('''
                    background-color: white;
                    padding: 2rem;
                    border-radius: 16px;
                    box-shadow: 0 4px 16px rgba(0,0,0,0.2);
                    width: 100%;
                '''):
                    ui.label("Agendar Cita Veterinaria").style('''
                        font-size: 24px;
                        font-weight: bold;
                        color: #1e293b;
                        margin-bottom: 1rem;
                    ''')

                    mascota_select = ui.select(
                        options=nombres_mascotas,
                        label="Selecciona Mascota"
                    ).props('clearable outlined').classes('custom-input').style('''
                        width: 100%;
                        margin-bottom: 1rem;
                        color: white;
                    ''')

                    fecha_input = ui.input(
                        label="Fecha de la cita"
                    ).props('type=date').classes('custom-input').style('''
                        width: 100%;
                        margin-bottom: 1rem;
                        color: white;
                    ''')

                    hora_input = ui.input(
                        label="Hora de la cita"
                    ).props('type=time').classes('custom-input').style('''
                        width: 100%;
                        margin-bottom: 1rem;
                        color: white;
                    ''')

                    ui.label("Motivo de la cita").style('''
                        color: #1e293b;
                        text-align: left;
                        width: 100%;
                        margin-bottom: 0.2rem;
                    ''')
                    motivo_input = ui.input(
                        placeholder="Describa el motivo o síntomas"
                    ).classes('custom-input').style('''
                        width: 100%;
                        margin-bottom: 1rem;
                    ''')

                    # NUEVO: Indicador de estado del día seleccionado
                    estado_dia_label = ui.label("").style('''
                        color: white;
                        margin-bottom: 1rem;
                        text-align: center;
                        font-weight: bold;
                    ''')

                    def verificar_disponibilidad_dia():
                        """Verifica y muestra el estado del día seleccionado con mejor diseño"""
                        fecha = fecha_input.value
                        if fecha:
                            citas = calendario_local.obtener_citas()
                            resultado = analizar_estado_dia(fecha, citas)

                            estado_dia_label.text = resultado['texto']
                            estado_dia_label.style(resultado['estilo'])
                        else:
                            estado_dia_label.text = "👆 Selecciona una fecha para ver disponibilidad"
                            estado_dia_label.style('''
                                color: #888;
                                font-style: italic;
                                text-align: center;
                                padding: 12px;
                                border-radius: 8px;
                                margin-bottom: 1rem;
                                width: 100%;
                                display: block;
                                background-color: transparent;
                                border: none;
                            ''')
                    # Conectar verificación cuando cambie la fecha - MEJORADO
                    fecha_input.on('input', lambda _: verificar_disponibilidad_dia())
                    fecha_input.on_value_change(lambda _: verificar_disponibilidad_dia())

                    # Inicializar la verificación
                    verificar_disponibilidad_dia()

                    def agendar():
                        resultado = validar_y_agendar(
                            mascota_select.value,
                            fecha_input.value,
                            hora_input.value,
                            motivo_input.value,
                            id_por_nombre,
                            calendario_local,
                            db,
                            session_veterinarian_id,
                            veterinario
                        )

                        ui.notify(resultado['mensaje'], type=resultado['tipo'])

                        if resultado['ok']:
                            mascota_select.value = None
                            fecha_input.value = ""
                            hora_input.value = ""
                            motivo_input.value = ""
                            estado_dia_label.text = ""

                            actualizar_lista_citas()
                            aplicar_estilos_calendario()

                    ui.button("Agendar Cita",
                        on_click=agendar).props('color=primary outlined')\
                            .style("width: 100%;")

                    # --- Botón Agregar Mascota debajo ---
                    def mostrar_formulario_mascota():
                        image_path = {'url': None}

                        def handle_upload(e):
                            if not e.content:
                                ui.notify('❌ No se seleccionó ninguna imagen')
                                return

                            content = e.content.read()
                            public_url = subir_imagen_mascota(db, e.name, content)
                            if public_url:
                                image_path['url'] = public_url
                                ui.notify('✅ Imagen subida correctamente')
                            else:
                                ui.notify('❌ Error al subir imagen')

                        with ui.dialog() as dialog, ui.card().style('''
                            background-color: white;
                            border-radius: 12px;
                            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                            padding: 2rem;
                            width: 100%;
                            max-width: 500px;
                            margin: auto;
                            display: flex;
                            flex-direction: column;
                        '''):
                            nombre = ui.input("Nombre:")\
                                .props('outlined')\
                                .classes('custom-input mb-2')\
                                .style('''
                                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                                ''')
                            especie = ui.input("Especie:")\
                                .props('outlined')\
                                .classes('custom-input mb-2')\
                                .style('''
                                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                                ''')
                            raza = ui.input("Raza:")\
                                .props('outlined')\
                                .classes('custom-input mb-2')\
                                .style('''
                                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                                ''')
                            edad = ui.number("Edad:")\
                                .props('outlined')\
                                .classes('custom-input mb-2')\
                                .style('''
                                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                                ''')
                            sexo = ui.select(
                                options=['Macho', 'Hembra'],
                                label="Sexo:"
                            ).props('outlined').classes('custom-input mb-2').style('''
                                width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                            ''')
                            peso = ui.number("Peso (kg):") \
                                .props('outlined min=0 step=0.1') \
                                .classes('custom-input mb-2') \
                                .style('''
                                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                                ''')
                            notas = ui.textarea("Notas:")\
                                .props('outlined')\
                                .classes('custom-input mb-2')\
                                .style('''
                                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px;
                                ''')
                            duenio = ui.input("Nombre del dueño:")\
                                .props('outlined')\
                                .classes('custom-input mb-4')\
                                .style('''
                                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                                ''')
                            contacto_duenio = ui.input("Contacto del dueño:")\
                                .props('outlined')\
                                .classes('custom-input mb-4')\
                                .style('''
                                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                                ''')
                            ui.upload(label='Subir foto de la mascota',
                                    auto_upload=True,
                                    on_upload=handle_upload)\
                                .classes('mb-4')

                            def guardar_mascota():
                                campos = {
                                    "nombre": nombre.value,
                                    "especie": especie.value,
                                    "raza": raza.value,
                                    "edad": edad.value,
                                    "sexo": sexo.value,
                                    "peso": peso.value,
                                    "duenio": duenio.value,
                                    "contacto_duenio": contacto_duenio.value,
                                    "notas": notas.value,
                                    "foto": image_path['url']
                                }

                                # Campos obligatorios a validar
                                campos_obligatorios = {
                                    k: campos[k] for k in [
                                        "nombre",
                                        "especie",
                                        "raza",
                                        "edad",
                                        "sexo",
                                        "peso",
                                        "duenio",
                                        "contacto_duenio"
                                    ]
                                }

                                faltantes = validar_campos_mascota(campos_obligatorios)
                                if faltantes:
                                    ui.notify(
                                        f"⚠️ Campos obligatorios incompletos: {
                                            ', '.join(faltantes)
                                        }", type='warning'
                                    )
                                    return

                                resultado = guardar_nueva_mascota(
                                    db, campos, session_veterinarian_id
                                )

                                if resultado.get('ok'):
                                    ui.notify("✅ Mascota agregada correctamente", type='positive')
                                    nuevas_mascotas = db.select_pet(session_veterinarian_id)
                                    opciones = [(m["name"], m["id"]) for m in nuevas_mascotas]
                                    mascota_select.options = opciones
                                    mascota_select.update()
                                    dialog.close()
                                else:
                                    ui.notify(
                                        resultado.get(
                                            'error',
                                            '❌ Error al guardar la mascota'
                                        ),type='negative'
                                    )

                            with ui.row().classes('gap-4'):
                                ui.button("Guardar",
                                    on_click=guardar_mascota).props('color=primary')
                                ui.button("Cancelar",
                                    on_click=dialog.close).props('color=primary outline')

                        dialog.open()

                    ui.button('Agregar Mascota',
                        on_click=mostrar_formulario_mascota)\
                            .props('color= primary')\
                            .classes('q-mt-md')\
                            .style("width: 100%; margin-top: 1rem;")

            # --- Botón Volver abajo a la derecha ---
            with ui.row().classes('fixed bottom-4 right-4'):
                ui.button("Volver al Panel",
                    on_click=lambda: ui.run_javascript("window.location.href = '/principal';")
                ).classes(
                    'fixed bottom-6 right-6 bg-gray-200 hover:bg-gray-300 '
                    'text-gray-800 py-3 px-5 rounded-lg shadow-lg flex items-center gap-2'
                ).props('unelevated icon=arrow_back_ios').style('z-index: 1000;')

            # Columna derecha: Calendario
            with ui.element().classes("calendar-column"):

                fecha_hoy = date.today().isoformat()
                fecha_seleccionada = ui.date(value=fecha_hoy)\
                    .props('label=Selecciona un día')\
                    .style('''
                        width: 100%;
                        font-size: 1.3rem;
                        margin-bottom: 1rem;
                    ''')

                # CONTENEDOR PRINCIPAL CENTRADO PARA LAS CITAS
                with ui.column().classes('items-center w-full'):
                    # Título de la sección
                    ui.label('Turnos agendados para el día seleccionado')\
                        .style('''
                            color: #1e293b;
                            font-weight: bold;
                            margin-bottom: 10px;
                        ''')
                    # Contenedor de las filas de turnos
                    citas_container = ui.column().classes('gap-2 w-full items-center')

            def actualizar_lista_citas():
                citas_container.clear()
                fecha = fecha_seleccionada.value
                citas_del_dia = obtener_citas_del_dia(calendario_local, fecha)

                if not citas_del_dia:
                    with citas_container:
                        ui.label('No hay citas agendadas para este día').style('''
                            color: #1e293b;
                            font-weight: 500;
                            text-align: center;
                            margin-top: 20px;
                            font-style: italic;
                            padding: 20px;
                        ''')
                    return

                for cita in citas_del_dia:
                    with citas_container:
                        with ui.row().classes('items-center justify-between').style(
                            'background-color: rgba(100, 181, 246, 0.6);'
                            'border-radius: 12px; padding: 14px 18px; margin-bottom: 10px; '
                            'width: 400px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);'
                        ):
                            ui.label(
                                f"{cita['hora']} - {cita['pet_name']} - {cita['motivo']}"
                            ).style(
                                'color: #1e293b;'
                                'font-weight: 500;'
                            )

                            def crear_eliminar_cita(cita):
                                def confirmar_eliminar():
                                    with ui.dialog() as dialog, ui.card():
                                        ui.label('¿Estás seguro de eliminar esta cita?').style('''
                                            color: #1e293b; font-size: 16px; margin-bottom: 16px;
                                        ''')
                                        ui.label(
                                            f"{cita['hora']} - {cita['pet_name']} - {cita['motivo']}"
                                        ).style('margin-bottom: 16px; color: #1e293b;')

                                        with ui.row().classes('justify-end gap-2'):
                                            ui.button(
                                                'Cancelar',
                                                on_click=dialog.close
                                            ).props('flat color=grey')

                                            def eliminar_confirmado():
                                                resultado = eliminar_cita_por_id(
                                                    calendario_local,
                                                    cita['id']
                                                )
                                                if resultado.get("ok"):
                                                    ui.notify(
                                                        "✅ Cita eliminada exitosamente",
                                                        type='positive'
                                                    )
                                                    dialog.close()
                                                    actualizar_lista_citas()
                                                    aplicar_estilos_calendario()
                                                    # Eventos
                                                    eventos = []
                                                    citas = calendario_local.obtener_citas()
                                                    eventos.clear()
                                                    eventos.extend(generar_eventos(citas))
                                                else:
                                                    ui.notify(resultado['error'], type='negative')

                                            ui.button(
                                                'Eliminar',
                                                on_click=eliminar_confirmado
                                            ).props('color=negative')
                                    dialog.open()
                                return confirmar_eliminar

                            ui.button(icon='delete', on_click=crear_eliminar_cita(cita))\
                                .props('color=negative size=sm flat round')\
                                    .style('min-width: 32px;')

                actualizar_lista_citas()  # Mostrar citas del día actual al cargar

                # NUEVO: Aplicar estilos al calendario después de que se cargue
                ui.timer(1.0, aplicar_estilos_calendario, once=True)


ui.run(storage_secret="Peluchitos2025")