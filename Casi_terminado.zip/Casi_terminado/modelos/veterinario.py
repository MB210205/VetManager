"""
Módulo Veterinario

Define la clase Veterinario para representar y manejar la información
de veterinarios en el sistema, incluyendo registro, carga y actualización
en la base de datos.
"""
from postgrest import APIError


class Veterinario:
    """
    Representa un veterinario con sus datos y operaciones básicas.

    Permite registrar, cargar, actualizar y obtener información
    relacionada al veterinario en la base de datos.
    """
    def __init__(self, email, nombre=None, password_hash=None):
        self.id = None
        self.email = email
        self.nombre = nombre
        self.password_hash = password_hash
        self.profile_imagen = None
        # — NUEVO —
        self.genero       = None
        self.phone_number = None
        self.age          = None
        self.address      = None
        self.matricula      = None

    def registrar(self, db):
        """
        Registra el veterinario en la base de datos.
        """
        return db.insert_veterinarian(self.email, self.nombre, self.password_hash)

    def cargar_desde_db(self, db):
        """
        Carga los datos del veterinario desde la base de datos usando el email.
        """
        result = db.get_veterinarian_by_email(self.email)
        if result.data:
            self.id = result.data['id']
            self.nombre = result.data['name']
            self.password_hash = result.data['password_hash']
            return True
        return False

    def cargar_por_id(self, db, veterinarian_id):
        """
        Carga los datos del veterinario desde la base de datos usando su ID.
        """
        result = db.get_veterinarian_by_id(veterinarian_id)
        # DEBUG: vemos todo el payload que viene de la BD
        print("⏱️ DEBUG get_veterinarian_by_id:", result.data)

        if result.data:
            self.id = result.data['id']
            self.email = result.data['email']
            self.nombre = result.data['name']
            self.password_hash = result.data.get('password_hash')  # No rompe si no existe
            self.profile_imagen = result.data.get('profile_imagen')
             # aquí recogemos el campo exacto de tu tabla:
            self.profile_imagen = result.data.get('profile_imagen')
            # DEBUG: imprimimos el valor final de la propiedad
            print("⏱️ DEBUG profile_imagen asignado a objeto:", self.profile_imagen)

            self.genero = result.data.get('genero')
            self.phone_number = result.data.get('phone_number')
            self.age = result.data.get('age')
            self.address = result.data.get('address')
            # Consultar matrícula por nombre en padrón

            try:
                matricula_resp = db.supabase.table('padron_veterinarios')\
                    .select('matricula')\
                    .eq('asociado_nombre', self.nombre)\
                    .single()\
                    .execute()

                self.matricula = matricula_resp.data.get('matricula')

            except APIError as e:
                print(f"⚠️ APIError: no se encontró matrícula o hubo un error: {e}")
                self.matricula = None
        return False

    def to_dict(self):
        """
        Convierte el objeto Veterinario a un diccionario.
        """
        return {
            'id': self.id,
            'email': self.email,
            'nombre': self.nombre
        }

    def obtener_nombre_veterinario(self, db, veterinarian_id):
        """
        Obtiene el nombre del veterinario dado su ID.
        """
        result = db.get_veterinarian_by_id(veterinarian_id)
        if result.data:
            return result.data['name']
        return None

    def actualizar_en_db(self, db):
        """
        Actualiza los datos del veterinario en la base de datos.
        """
        if not self.id:
            raise ValueError("El ID del veterinario no está definido")
        update_data = {
            'name': self.nombre,
            'email': self.email,
            'password_hash': self.password_hash
        }
        db.update_veterinarian(self.id, update_data)
