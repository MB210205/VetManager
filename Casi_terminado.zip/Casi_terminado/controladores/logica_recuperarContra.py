from postgrest.exceptions import APIError as AuthApiError
import httpx

def enviar_correo_recuperacion(supabase_auth, email):
    """
    Lógica para enviar correo de recuperación.
    Devuelve: (ok: bool, mensaje: str)
    """
    
    if not email:
        return False, "Por favor, ingresa tu correo electrónico."

    try:
        supabase_auth.reset_password_email(email)
        return True, "✅ Se envió el correo de recuperación"
    except AuthApiError as err:
        return False, f"❌ Error en la API de Supabase: {err}"
    except httpx.HTTPError as err:
        return False, f"❌ Error de red al enviar correo: {err}"