import re

def validar_datos_registro(nombre, email, password, confirm_password, matricula):
    if not all([nombre, email, password, confirm_password, matricula]):
        return False, 'Por favor completa todos los campos'

    if password != confirm_password:
        return False, 'Las contraseñas no coinciden'

    if len(password) < 8:
        return False, 'La contraseña debe tener al menos 8 caracteres'

    if not re.search(r'[A-Z]', password):
        return False, 'La contraseña debe tener al menos una letra mayúscula'

    if not re.search(r'[a-z]', password):
        return False, 'La contraseña debe tener al menos una letra minúscula'

    if not re.search(r'[0-9]', password):
        return False, 'La contraseña debe tener al menos un número'

    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False, 'La contraseña debe tener al menos un carácter especial'

    return True, ''

def registrar_veterinario(admin, encuesta, email, nombre, password, matricula):
    res = admin.registrar_veterinario(email, nombre, password, matricula)
    if res['ok']:
        encuesta.programar(email, nombre, minutos=1)
        return True, '✅ Registro exitoso. Revisa tu casilla de correo para verificar tu cuenta.'
    else:
        error_msg = res.get('error', '').lower()
        if 'duplicate' in error_msg or 'already exists' in error_msg:
            return False, '❌ El correo electrónico ya está registrado.'
        else:
            return False, f'❌ {res["error"]}'