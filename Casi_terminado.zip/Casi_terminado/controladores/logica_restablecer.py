import os
import re
import httpx
from supabase import AuthApiError, create_client
from dotenv import load_dotenv
from nicegui import ui

load_dotenv()
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)


def validar_password(pwd: str):
    if len(pwd) < 8:
        return False, 'La contraseña debe tener al menos 8 caracteres'
    if not re.search(r'[A-Z]', pwd):
        return False, 'Debe tener al menos una letra mayúscula'
    if not re.search(r'[a-z]', pwd):
        return False, 'Debe tener al menos una letra minúscula'
    if not re.search(r'[0-9]', pwd):
        return False, 'Debe tener al menos un número'
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', pwd):
        return False, 'Debe tener al menos un carácter especial'
    return True, ''


def cambiar_contrasenia(access_token: str, nueva_pwd: str, repetir_pwd: str):
    if nueva_pwd != repetir_pwd:
        ui.notify('⚠️ Las contraseñas no coinciden', type='warning')
        return

    ok, mensaje = validar_password(nueva_pwd)
    if not ok:
        ui.notify(f'⚠️ {mensaje}', type='warning')
        return

    try:
        r = httpx.put(
            f"{SUPABASE_URL}/auth/v1/user",
            headers={
                "Authorization": f"Bearer {access_token}",
                "apikey": SUPABASE_ANON_KEY,
            },
            json={"password": nueva_pwd}
        )
        if r.status_code == 200:
            ui.notify(
                '✅ Contraseña actualizada correctamente. Redirigiendo al login...',
                type='positive'
            )
            ui.run_javascript("setTimeout(() => { window.location.href = '/login'; }, 2500)")
        else:
            ui.notify(
                f'❌ Error al actualizar contraseña: {r.status_code} - {r.text}',
                type='negative'
            )

    except AuthApiError as err:
        ui.notify(f'❌ Error en la API de Supabase: {err}', type='negative')

    except httpx.HTTPError as err:
        ui.notify(f'❌ Error de red al actualizar contraseña: {err}', type='negative')