from uuid import uuid4
import httpx
from postgrest import APIError
from modelos.dbbroker import SupabaseBroker

def subir_imagen_y_guardar(db, e, veterinarian_id):
    db = SupabaseBroker()
    if not e.content:
        return (False, '❌ No se seleccionó ninguna imagen')

    key = f"veterinarios/{uuid4()}_{e.name}"
    content = e.content.read()

    try:
        db.supabase.storage.from_('veterinarios').upload(key, content)
        public_url = db.supabase.storage.from_('veterinarios').get_public_url(key)
        db.update_veterinarian(veterinarian_id, {'profile_imagen': public_url})
        return (True, public_url)
    except (APIError, httpx.HTTPError) as err:
        return (False, str(err))

def guardar_datos_perfil(db, veterinarian_id, datos_actualizados):
    db = SupabaseBroker()
    if not datos_actualizados:
        return (False, '⚠️ No hay cambios para guardar')
    try:
        resultado = db.update_veterinarian(veterinarian_id, datos_actualizados)
        if resultado and resultado.data is not None:
            return (True, '✅ Perfil actualizado')
        return (False, '❌ No se pudo actualizar')
    except APIError as err:
        return (False, f'❌ Error en PostgREST al actualizar perfil: {err}')
    except httpx.HTTPError as err:
        return (False, f'❌ Error de red al actualizar perfil: {err}')