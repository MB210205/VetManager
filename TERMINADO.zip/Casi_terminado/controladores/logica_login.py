def validar_login(email, password):
    if not email or not password:
        return False, 'Por favor completa todos los campos'
    return True, ''

def autenticar_veterinario(admin, db, email, password):
    res = admin.login_veterinario(email, password)

    if not res['ok']:
        return False, None, f"❌ {res.get('error', 'Credenciales inválidas')}"

    veterinario = db.get_veterinarian_by_email(email)
    print("DEBUG - veterinario:", veterinario)
    print("DEBUG - veterinario.data:", getattr(veterinario, 'data', None))

    if not veterinario or not getattr(veterinario, 'data', None):
        return False, None, 'No se encontró información adicional del veterinario'

    veterinarian_id = veterinario.data['id']
    nombre = veterinario.data.get("nombre", email)  # ✔ ahora sí usamos el nombre correcto

    return True, (veterinarian_id, nombre), f'✅ Bienvenido {nombre}'