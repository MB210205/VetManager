# logic/calendario_logic.py

from datetime import datetime, date, timedelta
from smtplib import SMTPException
from uuid import uuid4
from httpx import HTTPError
from postgrest import APIError

from modelos.dbbroker import SupabaseBroker
from modelos.veterinario import Veterinario
from modelos.mascota import Mascota
from utils.email_utils import send_email

# Límites para colorear el calendario / estados
LIMITE_OCUPADO = 6
LIMITE_COMPLETO = 10

def obtener_estado_dias(citas):
    """Retorna dict fecha_str → estado ('libre','disponible','ocupado','completo')."""
    conteo = {}
    for c in citas:
        key = str(c['fecha'])
        conteo[key] = conteo.get(key, 0) + 1
    estados = {}
    for fecha, cnt in conteo.items():
        if cnt >= LIMITE_COMPLETO:
            estados[fecha] = 'completo'
        elif cnt >= LIMITE_OCUPADO:
            estados[fecha] = 'ocupado'
        elif cnt > 0:
            estados[fecha] = 'disponible'
        else:
            estados[fecha] = 'libre'
    return estados

def obtener_estadisticas(vet_id, db: SupabaseBroker, citas):
    """
    Calcula estadísticas clave:
    - total_mascotas
    - total_citas_futuras (>= ahora)
    - total_citas_hoy
    """
    mascotas = db.select_pet(vet_id)
    total_mascotas = len(mascotas)

    ahora = datetime.now()
    citas_futuras = [
        c for c in citas
        if datetime.strptime(f"{c['fecha']} {str(c['hora'])[:5]}",
                             "%Y-%m-%d %H:%M") >= ahora
    ]
    total_citas_futuras = len(citas_futuras)

    hoy_str = date.today().isoformat()
    citas_hoy = [c for c in citas if str(c['fecha']) == hoy_str]
    total_citas_hoy = len(citas_hoy)

    return total_mascotas, total_citas_futuras, total_citas_hoy

def analizar_estado_dia(fecha, citas, limites=None):
    """
    Para un día concreto retorna:
    { 'estado','turnos','texto','estilo' }
    """
    if not limites:
        limites = { 'ocupado': LIMITE_OCUPADO, 'completo': LIMITE_COMPLETO }
    cantidad = sum(1 for c in citas if str(c['fecha']) == fecha)
    if cantidad >= limites['completo']:
        estado, color, texto = 'completo', '#F44336', f"🔴 DÍA COMPLETO ({cantidad})"
    elif cantidad >= limites['ocupado']:
        estado, color, texto = 'ocupado', '#FF9800', f"🟡 DÍA OCUPADO ({cantidad})"
    elif cantidad > 0:
        estado, color, texto = 'disponible', '#4CAF50', f"🟢 DISPONIBLE ({cantidad})"
    else:
        estado, color, texto = 'libre', '#4CAF50', "📅 DÍA LIBRE"
    estilo = (
        f"color:{color};"
        f"background-color:{color}26;"
        "font-weight:bold;"
        "padding:12px;"
        "border-radius:8px;"
        f"border:1px solid {color};"
    )
    return { 'estado': estado, 'turnos': cantidad, 'texto': texto, 'estilo': estilo }

def filtrar_citas_por_dia(citas, fecha_str):
    """Filtra y ordena cronológicamente las citas de un día."""
    lista = [c for c in citas if str(c['fecha']) == fecha_str]
    return sorted(lista, key=lambda x: x['hora'])

def validar_y_agendar(
    pet_name, fecha_str, hora_str, motivo,
    id_por_nombre, calendario, db: SupabaseBroker,
    vet_id: str, veterinario: Veterinario
):
    """
    Valida campos y agendamiento. Retorna dict con ok,mensaje,tipo,eventos,errores_email.
    """
    # Validaciones básicas
    if not pet_name:
        return {'ok': False,'mensaje':"Selecciona una mascota",'tipo':'warning'}
    if not fecha_str:
        return {'ok': False,'mensaje':"Selecciona una fecha",'tipo':'warning'}
    if not hora_str:
        return {'ok': False,'mensaje':"Selecciona una hora",'tipo':'warning'}
    if not motivo.strip():
        return {'ok': False,'mensaje':"Escribe el motivo",'tipo':'warning'}

    # Estado del día
    citas_all = calendario.obtener_citas()
    estados = obtener_estado_dias(citas_all)
    if estados.get(fecha_str)=='completo':
        return {'ok': False,'mensaje':"Día completo",'tipo':'negative'}

    # Convertir hora y validar solapamiento
    try:
        hora_obj = datetime.strptime(hora_str, "%H:%M").time()
    except ValueError as e:
        return {'ok': False,'mensaje':f"Hora inválida: {e}",'tipo':'negative'}
    if any(
        str(c['fecha'])==fecha_str and
        abs(
            datetime.combine(date.min, datetime.strptime(str(c['hora'])[:5],"%H:%M").time())
            - datetime.combine(date.min, hora_obj)
        ) < timedelta(hours=1)
        for c in citas_all
    ):
        return {'ok': False,'mensaje':"Menos de 1h de diferencia",'tipo':'negative'}

    # Obtener pet_id
    pet_id = id_por_nombre.get(pet_name)
    if pet_id is None:
        return {'ok': False,'mensaje':"Mascota desconocida",'tipo':'warning'}

    # Agenda la cita
    fecha = datetime.strptime(fecha_str, "%Y-%m-%d").date()
    try:
        calendario.agendar_cita(pet_id=pet_id, fecha=fecha, hora=hora_obj, motivo=motivo.strip())
    except Exception as e:
        return {'ok': False,'mensaje':str(e),'tipo':'negative'}

    # Notificación por email
    errores = []
    mascotas = db.select_pet(vet_id)
    pet = next((m for m in mascotas if m['id']==pet_id), None)
    recipients = [veterinario.email]
    if pet and pet.get('owner_contact') and '@' in pet['owner_contact']:
        recipients.append(pet['owner_contact'])
    subject = f"Nueva cita: {pet['name']} {fecha_str} {hora_str}"
    body = (
        f"Hola {veterinario.nombre},\n\n"
        f"Tienes nueva cita de *{pet['name']}*.\n"
        f"📅 {fecha_str}  ⏰ {hora_str}\n"
        f"💬 {motivo}\n"
    )
    for r in recipients:
        try:
            send_email(subject, body, r)
        except SMTPException as e:
            errores.append(str(e))

    eventos = [
        {
            "title": f"{c['pet_name']} – {c['motivo']}",
            "start": f"{c['fecha']}T{str(c['hora'])[:5]}"
        }
        for c in calendario.obtener_citas()
    ]

    return {'ok':True,'mensaje':"Cita agendada",'tipo':'positive','eventos':eventos,'errores_email':errores}

def eliminar_cita_por_id(calendario, cita_id):
    """Intenta eliminar y devuelve {'ok':bool,'error':msg}."""
    try:
        if calendario.eliminar_cita(cita_id):
            return {'ok':True}
        return {'ok':False,'error':"No se pudo eliminar"}
    except APIError as e:
        return {'ok':False,'error':f"API: {e}"}
    except HTTPError as e:
        return {'ok':False,'error':f"HTTP: {e}"}

def subir_imagen_mascota(db: SupabaseBroker, nombre: str, contenido: bytes) -> str:
    """Sube foto a Supabase y retorna URL pública o lanza HTTPError."""
    clave = f"{uuid4()}_{nombre}"
    resp = db.supabase.storage.from_('mascotas').upload(clave, contenido)
    if not resp:
        raise HTTPError("Error al subir imagen")
    return db.supabase.storage.from_('mascotas').get_public_url(clave)

def guardar_nueva_mascota(db: SupabaseBroker, datos: dict, vet_id: str) -> dict:
    """
    Crea y guarda Mascota. Retorna {'ok':True} o {'ok':False,'error':msg}.
    """
    try:
        m = Mascota(
            name=datos['nombre'], species=datos['especie'], breed=datos['raza'],
            age=int(datos['edad']), notes=datos.get('notas'),
            sexo=datos['sexo'], owner_name=datos['duenio'],
            owner_contact=datos['contacto_duenio'], peso=float(datos['peso']),
            photo_url=datos.get('foto'), id_vet=vet_id
        )
        res = m.guardar(db)
        if res and res.data:
            return {'ok':True}
        return {'ok':False,'error':"Fallo al guardar mascota"}
    except ValueError as e:
        return {'ok':False,'error':str(e)}

def validar_campos_mascota(campos: dict) -> list:
    """Devuelve lista de nombres de campos vacíos."""
    return [k for k,v in campos.items() if not v]

def generar_eventos(citas):
    """Formatea citas para calendario JS."""
    return [
        {"title":f"{c['pet_name']} - {c['motivo']}",
         "start":f"{c['fecha']}T{str(c['hora'])[:5]}"}
        for c in citas
    ]

def obtener_citas_del_dia(calendario, fecha: str):
    """
    Devuelve las citas ordenadas por hora para la fecha dada.
    """
    # asumo que tu Calendario tiene un método obtener_citas_con_id()
    citas = calendario.obtener_citas_con_id()
    filtradas = [c for c in citas if str(c['fecha']) == fecha]
    filtradas.sort(key=lambda c: c['hora'])
    return filtradas




