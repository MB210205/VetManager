"""
Módulo Calendario

Este módulo define la clase Calendario, que gestiona la agenda de citas y mascotas 
para un veterinario específico. Permite agregar mascotas, agendar y eliminar citas, 
consultar citas y verificar la disponibilidad en días y horarios.

Importa clases auxiliares como Cita y Mascota, y se integra con una base de datos 
para persistir la información de citas y mascotas.
"""
from datetime import date, timedelta, datetime
from postgrest import APIError         # para errores en insert/get/delete
import httpx  # si quieres capturar errores de bajo nivel HTTP

from modelos.cita import Cita
from modelos.mascota import Mascota

class Calendario:
    """
    Clase que gestiona la agenda de citas y mascotas para un veterinario.

    Permite agregar mascotas, agendar y eliminar citas, consultar citas y 
    verificar la disponibilidad en días y horarios.
    """
    def __init__(self, db, veterinarian_id):
        self.db = db
        self.veterinarian_id = veterinarian_id

    def agregar_mascota(self, name, species, breed, age, notes, owner_name, owner_contact=None):
        """Add a new pet for this veterinarian"""
        mascota = Mascota(
            name=name,
            species=species,
            breed=breed,
            age=age,
            notes=notes,
            owner_name=owner_name,
            owner_contact=owner_contact,
            id_vet=self.veterinarian_id
        )
        return mascota.guardar(self.db)

    def agendar_cita(self, pet_id, fecha, hora, motivo, limite_maximo=10):
        """Agenda una cita verificando primero la disponibilidad del día y el horario"""
        # Verificar si el día no está completo
        if not self.verificar_disponibilidad_dia(fecha, limite_maximo):
            raise ValueError(
                f"El día {fecha} ya tiene el máximo de turnos permitidos ({limite_maximo})"
            )

        # Verificar si la hora está dentro del horario de atención (8 a 20)
        if not 8 <= hora.hour < 20:
            raise ValueError("El horario de atención es de 08:00 a 20:00")

        # Verificar si la hora ya está ocupada
        horas_ocupadas = self.obtener_horas_ocupadas(fecha)
        hora_str = str(hora)
        if hora_str in horas_ocupadas:
            raise ValueError(f"La hora {hora} ya está ocupada en la fecha {fecha}")

        # Si llegamos aquí, podemos agendar la cita
        try:
            appointment_data = {
                'pet_id': pet_id,
                'veterinarian_id': self.veterinarian_id,
                'date': str(fecha),
                'time': hora_str,
                'reason': motivo,
                'status': 'programada'
            }

            response = self.db.insert_appointment(appointment_data)
            return response.data[0] if response.data else None


        except APIError as e:
            print(f"Error en la API de PostgREST al agendar: {e}")
            return False

        except httpx.HTTPError as e:
            print(f"Error HTTP al agendar la cita: {e}")
            return False

    def eliminar_cita(self, cita_id):
        """Elimina una cita por su ID"""
        try:
            self.db.supabase.table('appointments').delete().eq('id', cita_id).execute()
            return True    
        except APIError as e:
            print(f"Error en PostgREST al eliminar cita: {e}")
            return False

        except httpx.HTTPError as e:
            print(f"Error HTTP al eliminar cita: {e}")
            return False

    def listar_todas_las_citas(self):
        """Get all appointments for this veterinarian"""
        result = self.db.get_all_appointments(self.veterinarian_id)
        citas = []
        if result.data:
            for c in result.data:
                cita = Cita()
                cita.id = c['id']
                cita.pet_id = c['pet_id']
                cita.veterinarian_id = c['veterinarian_id']
                cita.fecha = datetime.strptime(c['date'], "%Y-%m-%d").date()
                cita.hora = datetime.strptime(c['time'], "%H:%M:%S").time()
                cita.reason = c['reason']
                cita.status = c['status']
                cita.pet_info = c.get('pets')
                citas.append(cita)
        return citas

    def obtener_citas(self):
        """
        Devuelve todas las citas del veterinario 
        en formato lista de diccionarios para el 
        calendario visual
        """
        citas_obj = self.listar_todas_las_citas()
        citas = []
        for c in citas_obj:
            pet_name = None
            if hasattr(c, 'pet_info') and c.pet_info and isinstance(c.pet_info, dict):
                pet_name = c.pet_info.get('name')
            if not pet_name and hasattr(c, 'pet_id'):
                pet_name = f"Mascota {c.pet_id}"
            citas.append({
                "pet_name": pet_name,
                "motivo": getattr(c, 'reason', ''),
                "fecha": c.fecha.isoformat() if hasattr(c, 'fecha') else '',
                "hora": str(c.hora)[:5] if hasattr(c, 'hora') else '',
            })
        # Ordenar por hora
        citas.sort(key=lambda x: x['hora'])
        return citas

    def obtener_citas_con_id(self):
        """Obtiene todas las citas incluyendo el ID para poder eliminarlas"""
        try:
            response = self.db.supabase.table('appointments')\
                .select('id, date, time, reason, pet_id, pets(name)')\
                    .eq('veterinarian_id', self.veterinarian_id).execute()

            citas = []
            for appointment in response.data:
                pet_name = (
                    appointment['pets']['name']
                    if appointment['pets']
                    else 'Mascota desconocida'
                )
                citas.append({
                    'id': appointment['id'],  # Incluir el ID
                    'fecha': appointment['date'],
                    'hora': appointment['time'],
                    'motivo': appointment['reason'],
                    'pet_name': pet_name
                })
            return citas
        except APIError as e:
            print(f"Error en PostgREST al obtener citas con ID: {e}")
            return []

        except httpx.HTTPError as e:
            print(f"Error HTTP al obtener citas con ID: {e}")
            return []

    def obtener_citas_por_dia(self, fecha):
        """Obtiene la cantidad de citas para un día específico"""
        try:
            response = self.db.get_appointments_by_day(self.veterinarian_id, fecha)
            return len(response.data) if response.data else 0
        except APIError as e:
            print(f"Error en PostgREST al obtener citas por día: {e}")
            return 0

        except httpx.HTTPError as e:
            print(f"Error HTTP al obtener citas por día: {e}")
            return 0

    def obtener_dias_ocupados(self, mes=None, anio=None):
        """Obtiene un diccionario con los días y su nivel de ocupación"""
        try:
            if mes is None or anio is None:
                hoy = date.today()
                mes = hoy.month
                anio = hoy.year

            response = self.db.get_appointments_by_month(self.veterinarian_id, mes, anio)
            conteo_dias = {}
            if response.data:
                for cita in response.data:
                    fecha = cita['fecha']
                    if fecha not in conteo_dias:
                        conteo_dias[fecha] = 0
                    conteo_dias[fecha] += 1
            return conteo_dias
        except APIError as e:
            print(f"Error en PostgREST al obtener días ocupados: {e}")
            return {}

        except httpx.HTTPError as e:
            print(f"Error HTTP al obtener días ocupados: {e}")
            return {}

    def obtener_horas_ocupadas(self, fecha):
        """Obtiene las horas ya ocupadas para un día específico"""
        try:
            response = self.db.get_occupied_hours(self.veterinarian_id, fecha)
            horas_ocupadas = []
            if response.data:
                for cita in response.data:
                    horas_ocupadas.append(str(cita['hora']))
            return horas_ocupadas
        except APIError as e:
            # Error en la API de PostgREST (SQL, permisos, etc.)
            print(f"Error en PostgREST al obtener horas ocupadas: {e}")
            return []

        except httpx.HTTPError as e:
            # Error de red / HTTP (timeout, DNS, SSL…)
            print(f"Error HTTP al obtener horas ocupadas: {e}")
            return []

    def verificar_disponibilidad_dia(self, fecha, limite_maximo=10):
        """Verifica si el día tiene menos citas que el límite máximo permitido"""
        cantidad_citas = self.obtener_citas_por_dia(fecha)
        return cantidad_citas < limite_maximo

    def sugerir_dias_disponibles(self, dias_adelante=30):
        """Sugiere días disponibles en los próximos N días"""

        dias_sugeridos = []
        fecha_actual = date.today()

        for i in range(1, dias_adelante + 1):
            fecha_check = fecha_actual + timedelta(days=i)
            # Saltar fines de semana si quieres (opcional)
            if fecha_check.weekday() < 5:  # Lunes a Viernes
                cantidad_citas = self.obtener_citas_por_dia(fecha_check)
                if cantidad_citas < 8:  # Días con menos de 8 citas
                    dias_sugeridos.append({
                        'fecha': fecha_check,
                        'citas_actuales': cantidad_citas,
                        'disponibilidad': 'alta' if cantidad_citas < 4 else 'media'
                    })

        return dias_sugeridos[:10]  # Devolver solo los primeros 10