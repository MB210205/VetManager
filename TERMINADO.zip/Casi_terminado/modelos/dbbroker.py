"""
Módulo SupabaseBroker

Este módulo proporciona una clase para interactuar con Supabase, incluyendo
operaciones relacionadas con veterinarios, mascotas y citas médicas.
"""
import os
from postgrest import APIError         # para errores en insert/get/delete
import httpx  # si quieres capturar errores de bajo nivel HTTP
from supabase import create_client, Client
from dotenv import load_dotenv

load_dotenv()

class SupabaseBroker:
    """
    Clase que maneja la comunicación con Supabase para veterinarios, mascotas y citas.
    """
    VETERINARIANS_TABLE = "veterinarians"
    APPOINTMENTS_TABLE = "appointments"
    PETS_TABLE = "pets"

    def __init__(self):
        url = os.getenv("SUPABASE_URL")
        key = os.getenv("SUPABASE_KEY")
        self.supabase: Client = create_client(url, key)

    # ================================
    # VETERINARIOS
    # ================================

    def insert_veterinarian(self, email, name, password_hash):
        """
        Inserta un nuevo veterinario en la base de datos.
        """
        return self.supabase.table(self.VETERINARIANS_TABLE).insert({
            "email": email,
            "name": name,
            "password_hash": password_hash
        }).execute()

    def get_veterinarian_by_email(self, email):
        """
        Busca un veterinario por su correo electrónico.
        """
        response = self.supabase.table(self.VETERINARIANS_TABLE).select("*")\
            .eq("email", email).maybe_single().execute()
        print("DEBUG response:", response)
        return response

    def get_veterinarian_by_id(self, vet_id):
        """
        Obtiene un veterinario por su ID.
        """
        return ( self.supabase
                .table("veterinarians")
                .select("id, email, name, profile_imagen, genero, phone_number, age, address")
                .eq("id", vet_id)
                .single()
                .execute() )

    def update_veterinarian(self, vet_id: str, updates: dict):
        """
        Actualiza los datos de un veterinario en la base de datos.
        """
        return self.supabase.table(self.VETERINARIANS_TABLE).update(updates)\
            .eq("id", vet_id).execute()

   #NUEVO
    def existe_matricula_en_padron(self, matricula: str) -> bool:
        """Devuelve True si la matrícula existe en padron_veterinarios."""
        try:
            # Llamada Upsert: maybe_single para 0 o 1 fila
            resp = (
                self.supabase
                    .table("padron_veterinarios")
                    .select("matricula")
                    .eq("matricula", matricula)
                    .maybe_single()
                    .execute()
            )
        except APIError as e:
            print(f"[❌] Error en PostgREST al consultar padrón: {e}")
            return False

        except httpx.HTTPError as e:
            print(f"[❌] Error HTTP al consultar padrón: {e}")
            return False

        # Si por alguna razón resp es None, lo tratamos como “no existe”
        if resp is None:
            return False

        # Si la respuesta trae atributo error, lo comprobamos
        if hasattr(resp, 'error') and resp.error:
            # Error real, lo imprimimos
            print(f"[⚠] Supabase error al consultar padrón: {resp.error}")
            return False

        # Si tiene data y no es None, existe; sino no
        return hasattr(resp, 'data') and resp.data is not None

    # ================================
    # MASCOTAS
    # ================================

    def insert_pets(
        self,
        name,
        species,
        breed,
        age,
        notes,
        owner_name,
        owner_contact,
        id_vet,
        photo_url=None,
        sexo=None,peso=None
    ):
        """
        Inserta una nueva mascota asociada a un veterinario.
        """
        print("Insertando en Supabase:", {
            "name": name,
            "species": species,
            "breed": breed,
            "age": age,
            "notes": notes,
            "owner_name": owner_name,
            "owner_contact": owner_contact,
            "id_vet": id_vet,
            "photo_url": photo_url,
            "sexo": sexo,
            "peso": peso
        })

        return self.supabase.table(self.PETS_TABLE).insert({
            "name": name,
            "species": species,
            "breed": breed,
            "age": age,
            "notes": notes,
            "owner_name": owner_name,
            "owner_contact": owner_contact,
            "id_vet": id_vet,
            "photo_url": photo_url,
            "sexo": sexo,
            "peso": peso
        }).execute()

    def select_pet(self, veterinarian_id):
        """
        Devuelve todas las mascotas asociadas a un veterinario.
        """
        response = self.supabase.table(self.PETS_TABLE).select("*")\
            .eq("id_vet", veterinarian_id).execute()
        return response.data

    def update_pet(self, pet_id: int, data: dict):
        """
        Actualiza los datos de una mascota por su ID.
        """
        response = self.supabase.table(self.PETS_TABLE).update(data).eq('id', pet_id).execute()
        return response.data

    def delete_pet(self, pet_id):
        """
        Elimina una mascota por su ID.
        """
        return self.supabase.table(self.PETS_TABLE).delete().eq("id", pet_id).execute()
    def get_pet_by_id(self, pet_id):
        """
        Devuelve los datos de una mascota específica por ID.
        """
        return self.supabase.from_('mascotas').select('*').eq('id', pet_id).single().execute()

    # ================================
    # CITAS/APPOINTMENTS
    # ================================

    def insert_appointments(self, pet_id, veterinarian_id, date, time, reason, status):
        """
        Inserta una cita médica con los campos básicos.
        """
        return self.supabase.table(self.APPOINTMENTS_TABLE).insert({
            "pet_id": pet_id,
            "veterinarian_id": veterinarian_id,
            "date": date,
            "time": time,
            "reason": reason,
            "status": status
        }).execute()

    def insert_appointment(self, appointment_data):
        """
        Inserta una cita médica con una estructura de datos personalizada.
        """
        return self.supabase.table(self.APPOINTMENTS_TABLE).insert(appointment_data).execute()

    def create_appointment(self, pet_id, veterinarian_id, fecha, hora_str, motivo):
        """
        Crea una cita usando nombres de campo en español.
        """
        appointment_data = {
            'pet_id': pet_id,
            'veterinarian_id': veterinarian_id,
            'fecha': str(fecha),
            'hora': hora_str,
            'motivo': motivo,
            'estado': 'programada'
        }
        return self.supabase.table(self.APPOINTMENTS_TABLE).insert(appointment_data).execute()

    def get_all_appointments(self, veterinarian_id):
        """
        Obtiene todas las citas de un veterinario con información de mascotas.
        """
        return self.supabase.table(self.APPOINTMENTS_TABLE).select(
            "id," \
            "date," \
            "time," \
            "reason," \
            "status," \
            "veterinarian_id," \
            "pet_id," \
            "pets:pet_id(id,name,species,breed,owner_name,owner_contact)"
        ).eq("veterinarian_id", veterinarian_id).order("date", desc=False).execute()


    def get_appointments_by_day(self, veterinarian_id, fecha):
        """
        Obtiene las citas programadas para un veterinario en una fecha específica.
        """
        return self.supabase.table(self.APPOINTMENTS_TABLE).select("*")\
            .eq("veterinarian_id", veterinarian_id)\
                .eq("fecha", str(fecha)).execute()

    def get_appointments_by_month(self, veterinarian_id, mes, anio):
        """
        Obtiene las fechas de las citas de un veterinario en un mes específico.
        """
        fecha_inicio = f"{anio}-{mes:02d}-01"
        if mes == 12:
            fecha_fin = f"{anio + 1}-01-01"
        else:
            fecha_fin = f"{anio}-{mes + 1:02d}-01"
        return self.supabase.table(self.APPOINTMENTS_TABLE).select('fecha')\
            .eq('veterinarian_id', veterinarian_id)\
                .gte('fecha', fecha_inicio).lt('fecha', fecha_fin).execute()

    def get_occupied_hours(self, veterinarian_id, fecha):
        """
        Obtiene las horas ya ocupadas por citas en una fecha dada.
        """
        return self.supabase.table(self.APPOINTMENTS_TABLE).select('hora')\
            .eq('veterinarian_id', veterinarian_id)\
                .eq('fecha', str(fecha)).execute()

    def delete_appointment(self, appointment_id):
        """
        Elimina una cita por ID con manejo de errores.
        """
        try:
            response = self.supabase.table(self.APPOINTMENTS_TABLE).delete()\
                .eq("id", appointment_id).execute()
            return response
        except Exception as e:
            print(f"Error al eliminar cita: {e}")
            raise e
    #NUEVO
    def get_appointments_by_pet(self, pet_id: int) -> list[dict]:
        """Devuelve todas las citas de una mascota, ordenadas por fecha y hora."""
        resp = (
            self.supabase
                .table(self.APPOINTMENTS_TABLE)
                .select("id, fecha, hora, motivo, estado, created_at")
                .eq("pet_id", pet_id)
                .order("fecha", desc=False)
                .order("hora", desc=False)
                .execute()
        )
        if resp.error:
            raise RuntimeError(f"Error al cargar historial de citas: {resp.error.message}")
        return resp.data
