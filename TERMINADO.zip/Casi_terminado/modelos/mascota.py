"""
Módulo Mascota

Define la clase Mascota para gestionar información de mascotas, incluyendo
carga, almacenamiento, eliminación y utilidades relacionadas.
"""
from modelos.dbbroker import SupabaseBroker

class Mascota:
    """
    Representa una mascota y sus atributos básicos.

    Permite guardar, cargar y eliminar mascotas en la base de datos,
    además de ofrecer utilidades estáticas para especies.
    """
    def __init__(
        self,
        name,
        species=None,
        breed=None,
        age=None,
        notes=None,
        owner_name=None,
        owner_contact=None,
        id_vet=None,
        photo_url='',
        sexo=None,
        peso=None
    ):
        self.name = name
        self.species = species
        self.breed = breed
        self.age = age
        self.notes = notes
        self.owner_name = owner_name
        self.owner_contact = owner_contact
        self.id = None
        self.id_vet = id_vet
        self.photo_url = photo_url
        self.sexo = sexo
        self.peso = peso

    def guardar(self, db):
        """
        Guarda la mascota en la base de datos.
        """
        self.sexo = self.sexo.lower() if self.sexo else self.sexo
        if self.sexo not in ['macho', 'hembra']:
            print(f"Error: sexo inválido ({self.sexo})")
            return None

        resultado = db.insert_pets(
            self.name,
            self.species,
            self.breed,
            self.age,
            self.notes,
            self.owner_name,
            self.owner_contact,
            self.id_vet,
            self.photo_url ,
            self.sexo,
            self.peso
        )
        if resultado.data:
            self.id = resultado.data[0]['id']
            print(f"Mascota guardada con id: {self.id}")
        else:
            print("No se pudo guardar la mascota")
        return resultado

    def cargar_desde_db(self, db_client: SupabaseBroker, pet_id):
        """
        Carga los datos de la mascota desde la base de datos por ID.
        """
        result = db_client.get_pet_by_id(pet_id)
        if result.data:
            self.id = result.data['id']
            self.name = result.data['name']
            self.species = result.data['species']
            self.breed = result.data['breed']
            self.age = result.data['age']
            self.notes = result.data['notes']
            self.owner_name = result.data['owner_name']
            self.owner_contact = result.data.get('owner_contact', '')
            self.id_vet = result.data['id_vet']
            self.photo_url = result.data.get('photo_url', '')
            self.sexo = result.data.get('sexo', '')
            self.peso = result.data.get('peso', None)
            return True
        return False

    def eliminar(self, db_client: SupabaseBroker):
        """
        Elimina la mascota de la base de datos.
        """
        if not self.id:
            return None
        return db_client.delete_pet(self.id)

    def to_dict(self):
        """
        Convierte el objeto Mascota a un diccionario.
        """
        return {
            'id': self.id,
            'name': self.name,
            'species': self.species,
            'breed': self.breed,
            'age': self.age,
            'notes': self.notes,
            'owner_name': self.owner_name,
            'owner_contact': self.owner_contact,
            'id_vet': self.id_vet,
            'photo_url': self.photo_url,
            'sexo': self.sexo,
            'peso': self.peso
        }

    @staticmethod
    def get_species_emoji(species):
        """
        Devuelve un emoji representativo según la especie.
        """
        species_lower = species.lower() if species else ""
        if 'perro' in species_lower or 'dog' in species_lower or 'canino' in species_lower:
            return '🐕'
        elif 'gato' in species_lower or 'cat' in species_lower or 'felino' in species_lower:
            return '🐱'
        elif 'ave' in species_lower or 'bird' in species_lower or 'pájaro' in species_lower:
            return '🐦'
        elif 'conejo' in species_lower or 'rabbit' in species_lower:
            return '🐰'
        elif 'roedor' in species_lower or 'hamster' in species_lower or 'ratón' in species_lower:
            return '🐹'
        else:
            return '🐾'

    @staticmethod
    def categorize_species(species: str) -> str:
        """
        Categoriza la especie en grupos generales.
        """
        species = species.lower()
        if "perro" in species:
            return "caninos"
        if "gato" in species:
            return "felinos"
        if "ave" in species or "loro" in species:
            return "aves"
        if "conejo" in species:
            return "conejos"
        if "hámster" in species or "roedor" in species:
            return "roedores"
        return "otros"
