"""
Módulo Cita

Este módulo define la clase Cita, que representa una cita veterinaria
y proporciona métodos para agendarla, cargarla desde la base de datos,
eliminarla y convertirla en un diccionario serializable.
"""
from datetime import date, datetime, time

class Cita:
    """
    Clase que representa una cita para una mascota con un veterinario.

    Atributos:
        pet_id (int): ID de la mascota.
        veterinarian_id (int): ID del veterinario.
        fecha (date): Fecha de la cita.
        hora (time): Hora de la cita.
        reason (str): Motivo de la cita.
        status (str): Estado de la cita (por defecto 'Pendiente').
        pet_info (dict): Información adicional de la mascota.
    """

    def __init__(
        self,
        pet_id=None,
        veterinarian_id=None,
        fecha=None,
        hora=None,
        reason=None,
        status='Pendiente'
    ):
        self.id = None
        self.pet_id = pet_id
        self.veterinarian_id = veterinarian_id
        self.fecha = fecha
        self.hora = hora
        self.reason = reason
        self.status = status
        self.pet_info = None  # For storing pet information when loaded from DB

    def agendar(self, db):
        """
        Agenda la cita en la base de datos.
        """
        return db.insert_appointments(
            self.pet_id,
            self.veterinarian_id,
            self.fecha.isoformat() if isinstance(self.fecha, date) else self.fecha,
            self.hora.strftime("%H:%M:%S") if isinstance(self.hora, time) else self.hora,
            self.reason,
            self.status
        )

    def cargar_desde_db(self, db, appointment_id):
        """
        Carga los datos de una cita desde la base de datos usando su ID.
        """
        result = db.get_appointment_by_id(appointment_id)
        if result.data:
            self.id = result.data['id']
            self.pet_id = result.data['pet_id']
            self.veterinarian_id = result.data['veterinarian_id']
            self.fecha = datetime.strptime(result.data['date'], "%Y-%m-%d").date()
            self.hora = datetime.strptime(result.data['time'], "%H:%M:%S").time()
            self.reason = result.data['reason']
            self.status = result.data['status']
            self.pet_info = result.data.get('pets')
            return True
        return False

    def eliminar(self, db):
        """
        Elimina la cita actual de la base de datos
        """
        if not self.id:
            return None
        return db.delete_appointment(self.id)

    def to_dict(self):
        """
        Convierte la cita en un diccionario serializable.
        """
        return {
            'id': self.id,
            'pet_id': self.pet_id,
            'veterinarian_id': self.veterinarian_id,
            'fecha': self.fecha,
            'hora': self.hora,
            'reason': self.reason,
            'status': self.status,
            'pet_info': self.pet_info
        }

    def set_reason(self, reason):
        """
        Establece el motivo de la cita, recortando a 100 caracteres si es necesario.
        """
        self.reason = reason
        if len(self.reason) > 100:
            self.reason = self.reason[:100]
