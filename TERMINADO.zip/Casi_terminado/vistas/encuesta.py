"""
Módulo para programar el envío de encuestas de satisfacción
utilizando APScheduler y una base de datos SQLite para persistencia.
"""
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from utils.email_utils import send_email

# ← Función a nivel de módulo (no dentro de la clase)
def enviar_encuesta_job(email: str, nombre: str = "") -> None:
    """
    Job que envía el mail con encuesta de satisfacción.
    """
    subject = "¡Ayúdanos a mejorar con tu opinión!"
    body = (
        f"Hola {nombre},\n\n"
        "Gracias por unirte a Peluchitos.\n"
        f"Por favor completa esta breve encuesta:\n{Encuesta.ENCUESTA_URL}\n\n"
        "— El equipo de Peluchitos"
    )
    send_email(subject, body, email)


class Encuesta:
    """
    Tarea programada que envía un correo electrónico con una encuesta de satisfacción.
    """
    ENCUESTA_URL = "https://forms.gle/23KjauEyFFFvaXW86"

    def __init__(self, db_url='sqlite:///jobs.sqlite'):
        jobstores = {'default': SQLAlchemyJobStore(url=db_url)}
        self.scheduler = BackgroundScheduler(jobstores=jobstores)
        self.scheduler.start()

    def programar(self, email: str, nombre: str, minutos: int = 15) -> None:
        """
        Programa el envío de una encuesta para el email y nombre indicados
        luego de un retraso especificado en minutos.
        """
        run_time = datetime.now() + timedelta(minutes=minutos)
        job_id = f"encuesta_{email}_{int(run_time.timestamp())}"
        self.scheduler.add_job(
            func=enviar_encuesta_job,   # ← referencia a la función de módulo
            trigger='date',
            run_date=run_time,
            args=[email, nombre],
            id=job_id,
            replace_existing=True
        )
