import os
from nicegui import ui
from dotenv import load_dotenv

from supabase import create_client
from controladores.logica_recuperarContra import enviar_correo_recuperacion


load_dotenv()
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)


# ✅ RECUPERAR CONTRASEÑA
@ui.page('/recuperar')
def recuperar():
    """
    Página para que el usuario pueda solicitar la recuperación de su contraseña.
    Muestra un formulario para ingresar el correo electrónico, el cual se utiliza
    para envíar un correo para restablecer la contraseña mediante Supabase.
    """
    ui.add_head_html('''
        <style>
            html, body {
                margin: 0;
                padding: 0;
                height: 100%;
                font-family: 'Poiret One', sans-serif;
                background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                            url('https://img.freepik.com/vector-premium/ilustracion-vectorial-patron-costuras-pata-gato-huella-pata-gato-aislada-sobre-fondo-blanco_478768-259.jpg?w=2000');
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
            }
            .titulo-vet {
                top: 20px;
                left: 20px;
                color: #1e293b;
                font-size: 80px;
                font-weight: bold;
                font-family: 'Playfair Display', serif;
                user-select: none; 
                cursor: default;
                margin-bottom: 30px; /* Espacio debajo del título */
                text-align: center;
            }
            .custom-input input {
                color: #1e293b; /* Gris claro */
            }
        </style>
    ''')
#___
    #CONTENEDOR PRINCIPAL
    with ui.column().style('''
            width: 100vw;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        '''):
       #Card del formulario
        with ui.card().classes('p-10 shadow-xl').style(
            'width: 550px; background-color: #ffffff; border-radius: 24px; color: #1e293b;'
        ):
            ui.label('🐾 Peluchitos').classes('titulo-vet')
            ui.label('Recuperar Contraseña').classes('titulo-animado text-4xl mb-8')

            #Campo email
            with ui.row().classes('w-full mb-6').style('position: relative; align-items: center;'):
                ui.icon('email').style('''
                        position: absolute; left: 12px; color: #1e293b; font-size: 24px;
                ''')
                email = ui.input()\
                    .props('outlined dense type=email clearable')\
                        .classes('w-full custom-input')
                email.props('placeholder="Correo electrónico"')
                email.style('padding-left: 50px; font-size: 18px; height: 50px;')

            #Mensaje informativo
            ui.label('Te enviaremos un correo para restablecer tu contraseña.')\
                .classes('text-gray-500 mb-4')

            def enviar_correo():
                ok, mensaje = enviar_correo_recuperacion(supabase.auth, email.value)
                tipo = 'positive' if ok else 'negative'
                ui.notify(mensaje, type=tipo)

            #Botones
            with ui.column().classes('w-full justify-between mt-6'):
                # Boton para recuperar contraseña
                ui.button("Recuperar Contraseña", on_click=enviar_correo)\
                    .props('color=primary unelevated')\
                        .classes('w-full font-semibold')\
                            .style('font-size: 15px; height: 50px; border-radius: 10px;')

                ui.button("Volver al login",
                        on_click=lambda: ui.run_javascript("window.location.href = '/login';")
                ).classes(
                    'fixed bottom-6 right-6 '
                    'bg-gray-200 hover:bg-gray-300 '
                    'text-gray-800 py-3 px-5 '
                    'rounded-lg shadow-lg '
                    'flex items-center gap-2'
                ).props('unelevated icon=arrow_back_ios').style('z-index: 1000;')