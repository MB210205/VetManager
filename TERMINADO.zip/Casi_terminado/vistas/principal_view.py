# pylint: disable=unused-import
# pyright: reportUnusedImport=false
# ------------------------
# Módulos estándar de Python
# ------------------------
import collections
import os

from datetime import datetime, date, timedelta
from uuid import uuid4 #para generar identificadores únicos (se usa al guardar imágenes).

# ------------------------
# Módulos de terceros
# ------------------------
from dotenv import load_dotenv
from nicegui import ui, app #el framework NiceGUI para construir la interfaz web.
from supabase import create_client

# ------------------------
# Módulos propios - paquetes del proyecto
# ------------------------
from modelos.dbbroker import SupabaseBroker #permite acceso a base de datos
from modelos.mascota import Mascota #clase para crear/guardar/editar registros de mascotas.
from modelos.veterinario import Veterinario #clase para cargar datos del veterinario en sesión.
from vistas.encuesta import Encuesta
from vistas.administradorPerfil import AdministradorPerfil
import vistas.inicio
import vistas.calendario_view
from modelos.calendario import Calendario
from utils.email_utils import send_email


load_dotenv()
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)


db = SupabaseBroker()
admin = AdministradorPerfil(db)
encuesta = Encuesta()  # usa sqlite:///jobs.sqlite por defecto


# ✅ PAGINA PRINCIPAL
@ui.page('/principal')
def principal():
    """
    Página principal del veterinario.

    Esta función verifica si el veterinario está logueado, carga sus datos 
    y genera la interfaz principal del sistema, que incluye:
    - Bienvenida y perfil del veterinario
    - Estadísticas (dashboard) de mascotas y turnos
    - Botones de navegación (mascotas, turnos, agregar mascota)
    - Gráfico con cantidad de turnos de los últimos 7 días
    - Tabla con próximos turnos agendados
    - Estilos personalizados para la página

    Si no hay sesión activa, redirige al inicio de sesión.
    """
    #Verificar login
    session_veterinarian_id = app.storage.user.get('veterinarian_id')
    if not session_veterinarian_id:
        ui.notify('Debes iniciar sesión', type='warning')
        ui.run_javascript("window.location.href = '/'")
        return

    #Cargar datos del vet
    veterinario = Veterinario(email=None)
    veterinario.cargar_por_id(db, session_veterinarian_id)
    nombre_vet = veterinario.nombre
    foto_url   = veterinario.profile_imagen

    
    #Instanciar el calendario, para poder usarlo en esta seccion
    calendario_local = Calendario(db, session_veterinarian_id)

    #Estadísticas para el mini–dashboard
    mascotas = db.select_pet(session_veterinarian_id)
    total_mascotas = len(mascotas)

    todas_citas = calendario_local.obtener_citas()
    ahora = datetime.now()
    citas_futuras = [
        c for c in todas_citas
        if datetime.strptime(f"{c['fecha']} {str(c['hora'])[:5]}", "%Y-%m-%d %H:%M") >= ahora
    ]
    total_citas_futuras = len(citas_futuras)

    hoy = date.today().isoformat()
    citas_hoy = [c for c in todas_citas if str(c['fecha']) == hoy]
    total_citas_hoy = len(citas_hoy)

    #Estilo y tipografía
    ui.add_head_html('''
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap" rel="stylesheet">
        <style>
            html, body {
                margin: 0;
                padding: 0;
                border: 0;
                overflow-x: hidden;
                width: 100vw;
                height: 100vh;
                font-family: 'Poiret One', sans-serif;
                background: linear-gradient(rgba(0,0,0,0.1), rgba(0,0,0,0.1)),
                            url('https://static.vecteezy.com/system/resources/previews/013/531/077/non_2x/doodle-background-pets-and-animals-care-products-free-vector.jpg');
                color: #1e293b !important;
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
            }
            .titulo-vet {
                position: fixed;
                top: 20px;
                left: 20px;
                color: #1e293b; /* gris oscuro azulado */
                font-size: 80px;
                font-weight: bold;
                font-family: 'Playfair Display', serif;
                user-select: none; 
                cursor: default;
            }
            .botones-container {
                width: 100vw;
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 2rem;
                margin-top: 20px;
                margin-bottom: 40px;
            }
            .boton-estilo {
                width: 300px;
                height: 70px;
                font-size: 24px;
                border-radius: 20px;
            }
            .tabla-turnos {
                background: white;
                color: #1e293b;
                border-radius: 18px;
                padding: 2rem;
                margin: auto;
                width: 700px;
                box-shadow: 0 4px 16px rgba(0,0,0,0.08);
            }
            .titulo-turnos {
                color: #222;
                font-size: 2.5rem;
                font-weight: bold;
                text-align: center;
                margin-bottom: 1.5rem;
            }
            .tabla-turnos-custom thead th {
                position: sticky;
                top: 0;
                background: #e6f0ff; /* un celeste muy suave */
                color: #000000;
                z-index: 1;
                padding: 0.75rem 1rem;
            }
            .tabla-turnos-custom tbody tr:hover {
                background-color: #f0f4ff; /* un celeste muy suave */
            }
            .form-column {
                flex: 0 0 auto;
                max-width: 650px;
                min-width: 600px;
            }
            body.light-mode {
            background: #f5f6fa !important;
            color: #23233a !important;
            }
            .light-mode .titulo-vet,
            .light-mode .q-field__label,
            .light-mode label,
            .light-mode .q-field__native {
                color: #23233a !important;
            }
            .light-mode .q-card,
            .light-mode .q-table,
            .light-mode .q-date,
            .light-mode .q-date__header {
                background: #fff !important;
                color: #23233a !important;
            }
            .light-mode .tabla-turnos-custom,
            .light-mode .form-column,
            .light-mode .calendar-column {
                background: #fff !important;
                color: #23233a !important;
            }
            .light-mode .q-btn {
                color: #23233a !important;
            }
        </style>
    ''')

    #CABECERA PRINCIPAL
    # Fila superior: Título a la izquierda, perfil a la derecha
    with ui.row().classes('w-full items-center justify-between').style('''
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1000;
        background-color: rgba(255, 255, 255, 0.75); 
        backdrop-filter: blur(6px);
        padding: 10px 40px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    '''):

        ui.label('🐾 Peluchitos').classes('titulo-vet') \
        .style('''
                position: static; 
                font-size: 80px; 
                font-weight: bold; 
                color: #1e293b; 
                font-family: "Playfair Display", serif; 
                margin-left: 40px;
            ''')

        ui.label(f'¡Bienvenido, veterinario/a {nombre_vet}!').style('''
            font-family: "Playfair Display", serif; 
            color: #334155; 
            font-size: 2.0rem;
            font-weight: 500;
        ''')

        with ui.row().classes('items-center gap-4').style('margin-right: 40px;'):
            if foto_url:
                # mostramos la imagen subida, ahora más grande
                ui.image(foto_url).classes(
                    'w-16 h-16 md:w-20 md:h-20 rounded-full cursor-pointer'
                ).on(
                    'click',
                    lambda: ui.run_javascript("window.location.href = '/configuracion';")
                )
            else:
                # icono por defecto
                ui.button(icon='account_circle',
                        on_click=lambda: ui.run_javascript(
                            "window.location.href = '/configuracion';"
                        )
                    ).props('flat round color=white size=xl')

    with ui.column().classes('items-center w-full').style('margin-top: 180px;'):
        # Creamos una fila de cards:
        with ui.row().classes('justify-center items-stretch gap-6 mb-8'):
            # Card de mascotas
            with ui.card().style('''
                    background: #d0e8ff; color: #1e293b; width: 200px; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                '''):
                with ui.row().classes('items-center gap-2'):
                    ui.icon('pets').style('font-size: 28px; color: #2563eb;')  # azul medio
                    ui.label('Mascotas').classes('text-lg font-medium mb-2')
                ui.label(str(total_mascotas)).classes('text-3xl font-bold')

            # Card de turnos futuros
            with ui.card().style('''
                    background: #a5d8ff; color: #1e293b; width: 200px; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                '''):
                with ui.row().classes('items-center gap-2'):
                    ui.icon('calendar_today').style('''
                        font-size: 28px; color: #1e40af;
                    ''')  # azul más oscuro
                    ui.label('Turnos futuros').classes('text-lg font-medium mb-2')
                ui.label(str(total_citas_futuras)).classes('text-3xl font-bold')

            # Card de hoy
            with ui.card().style('''
                    background: #7ec0ff; color: #1e293b; width: 200px; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                '''):
                with ui.row().classes('items-center gap-2'):
                    ui.icon('access_time').style('''
                        font-size: 28px; color: #1e3a8a;
                    ''')  # azul oscuro
                    ui.label('Hoy').classes('text-lg font-medium mb-2')
                ui.label(str(total_citas_hoy)).classes('text-3xl font-bold')
        # ─── FIN DEL MINI DASHBOARD ───

    # --- CONTENIDO PRINCIPAL ---
    #AGREGAR MASCOTA
    def mostrar_formulario_mascota(mascota_select):
        image_path = {'url': None}
        #sube la imagen a Supabase Storage y guarda la URL pública.
        def handle_upload(e):
            if not e.content:
                ui.notify('❌ No se seleccionó ninguna imagen')
                return
            name = f"{uuid4()}_{e.name}"
            content = e.content.read()
            result = db.supabase.storage.from_('mascotas').upload(name, content)
            if result:
                public_url = db.supabase.storage.from_('mascotas').get_public_url(name)
                image_path['url'] = public_url
                ui.notify('✅ Imagen subida correctamente')
            else:
                ui.notify('❌ Error al subir imagen')

        with ui.dialog() as dialog, ui.card().style(
            # Card: fondo blanco, bordes suaves y sombra ligera
            "background-color: #FFFFFF; "
            "border-radius: 12px; "
            "box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); "
            "padding: 2rem; "
            "width: 100%; max-width: 500px; "
            "margin: auto; "
            "display: flex; flex-direction: column; "
            "color: #334155;"
        ):

            ui.label('Nueva mascota 📝 ').classes('titulo-animado text-4xl mb-8')

            nombre = ui.input("Nombre:").props('outlined').classes('custom-input mb-2').style(
                "width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;")
            especie = ui.input("Especie:").props('outlined').classes('custom-input mb-2').style(
                "width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;")
            raza = ui.input("Raza:").props('outlined').classes('custom-input mb-2').style(
                "width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;")
            edad = ui.number("Edad:").props('outlined').classes('custom-input mb-2').style(
                "width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;")
            sexo = ui.select(
                options=['Macho', 'Hembra'],
                label="Sexo:"
            ).props('outlined').classes('custom-input mb-2').style(
                "width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;")
            peso = ui.number("Peso (kg):").props('outlined min=0 step=0.1')\
                .classes('custom-input mb-2')\
                .style('''
                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                ''')
            notas = ui.textarea("Notas:").props('outlined').classes('custom-input mb-2').style(
                "width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px;")
            duenio = ui.input("Nombre del dueño:").props('outlined')\
                .classes('custom-input mb-4')\
                .style('''
                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                ''')
            contacto_duenio = ui.input("Contacto del dueño:").props('outlined')\
                .classes('custom-input mb-4')\
                .style('''
                    width: 100%; margin-bottom: 1rem; color: #1e293b; font-size: 18px; height: 50px;
                ''')
            ui.upload(
                label='Subir foto de la mascota',
                auto_upload=True,
                on_upload=handle_upload
            ).classes('mb-4').style('color: #334155;')

            # Valida nombre, crea instancia Mascota y guarda en BD
            # Actualiza las opciones del select y cierra el diálogo si tiene éxito.
            def guardar_mascota():
                campos_obligatorios = {
                    "Nombre": nombre.value,
                    "Especie": especie.value,
                    "Raza": raza.value,
                    "Edad": edad.value,
                    "Sexo": sexo.value,
                    "Dueño": duenio.value,
                    "Contacto del dueño": contacto_duenio.value,
                    "Peso": peso.value,
                }
                # Verificar si falta algún campo obligatorio
                campos_faltantes = [
                    campo for campo, valor in campos_obligatorios.items() if not valor
                ]
                if campos_faltantes:
                    ui.notify(
                        f"⚠️ Campos obligatorios incompletos: {
                            ', '.join(campos_faltantes)
                        }",
                        type='warning'
                    )
                    return
                try:
                    nueva = Mascota(
                        name=nombre.value,
                        species=especie.value,
                        breed=raza.value,
                        age=int(edad.value),
                        notes=notas.value,
                        sexo=sexo.value,
                        owner_name=duenio.value,
                        owner_contact=contacto_duenio.value,
                        id_vet=session_veterinarian_id,
                        photo_url=image_path['url'],
                        peso=float(peso.value)
                    )

                    resultado = nueva.guardar(db)
                    if resultado and resultado.data:
                        ui.notify("✅ Mascota agregada correctamente", type='positive')
                        nuevas_mascotas = db.select_pet(session_veterinarian_id)
                        opciones = [(m["name"], m["id"]) for m in nuevas_mascotas]
                        mascota_select.options = opciones
                        mascota_select.update()
                        dialog.close()
                    else:
                        ui.notify("❌ Error al guardar la mascota", type='negative')

                except ValueError:
                    ui.notify("⚠️ Edad y peso deben ser valores numéricos válidos.", type='warning')

            with ui.row().classes('gap-4'):
                ui.button("Guardar",
                    on_click=guardar_mascota).props('color=primary')
                ui.button("Cancelar",
                    on_click=dialog.close).props('color=primary outline')
        dialog.open()

    #Botones principales
    with ui.row().classes('botones-container'):
        ui.button('Mis Mascotas',
                on_click=lambda: ui.run_javascript("window.location.href = '/mascotas';")
            ).classes('boton-estilo')\
                .style('background-color: #38bdf8; color: white;')
        ui.button('Agendar un turno',
                on_click=lambda: ui.run_javascript("window.location.href = '/calendario';")
            ).classes('boton-estilo')\
                .style('background-color: #60a5fa; color: white;')
        # Creamos un select temporal para pasar a la función
        mascota_select = ui.select(options=[],
                label="Selecciona Mascota").props('clearable outlined').classes('hidden')
        ui.button('Agregar Mascota',
                on_click=lambda: mostrar_formulario_mascota(mascota_select)
            ).classes('boton-estilo')\
                .style('background-color: #1e293b; color: white;')

    # ── Gráfico de turnos últimos 7 ──
    all_citas = calendario_local.obtener_citas()
    hoy_date = date.today()
    conteo_semana = collections.Counter(
        date.fromisoformat(c['fecha'])
        for c in all_citas
        if date.fromisoformat(c['fecha']) >= hoy_date - timedelta(days=6)
    )

    etiquetas = [
        (hoy_date - timedelta(days=i)).strftime('%-d/%-m')
        for i in reversed(range(7))
    ]
    valores = [
        conteo_semana.get(hoy_date - timedelta(days=i), 0)
        for i in reversed(range(7))
    ]

     # --- TABLA DE TURNOS PRÓXIMOS ---
    calendario_local = Calendario(db, session_veterinarian_id)
    citas = calendario_local.obtener_citas()
    # Filtra solo los turnos futuros
    ahora = datetime.now()
    citas_futuras = []
    for c in citas:
        try:
            fecha_hora = datetime.strptime(f"{c['fecha']} {str(c['hora'])[:5]}", "%Y-%m-%d %H:%M")
            if fecha_hora >= ahora:
                citas_futuras.append(c)
        except ValueError:
            pass  # Si hay error en el formato, ignora la cita

    # Ordena por fecha y hora
    citas_futuras = sorted(citas_futuras, key=lambda x: (x['fecha'], x['hora']))

    # Prepara filas para la tabla
    rows = []
    for c in citas_futuras:
        try:
            fecha_obj = datetime.strptime(str(c['fecha']), "%Y-%m-%d")
            fecha_formateada = fecha_obj.strftime("%d/%m/%Y")
        except ValueError:
            fecha_formateada = str(c['fecha'])
        rows.append({
            'hora': str(c['hora'])[:5],
            'dia': fecha_formateada,
            'mascota': c['pet_name'],
            'motivo': c['motivo']
        })

    columns = [
        {'name': 'hora', 'label': 'HORA', 'field': 'hora'},
        {'name': 'dia', 'label': 'DIA', 'field': 'dia'},
        {'name': 'mascota', 'label': 'MASCOTA', 'field': 'mascota'},
        {'name': 'motivo', 'label': 'MOTIVO', 'field': 'motivo'},
    ]

   # CONTENEDOR LATERAL: GRÁFICO + TABLA
    with ui.row().classes('justify-center items-start w-full gap-8').style('''
        margin-top: 3rem; flex-wrap: wrap;
    '''):

        # LADO IZQUIERDO: Gráfico de turnos
        with ui.column().style(
            '''
            background: white;
            padding: 2rem;
            border-radius: 18px;
            width: 700px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.08);
            color: #1e293b;
            display: flex;
            flex-direction: column;
            '''
        ):
            ui.label('Turnos: últimos 7 días').classes('titulo-turnos').style(
                '''
                text-align: center; 
                width: 100%;
                font-family: "Playfair Display", serif;
                color: #1e293b;
                text-align: center;
                margin-bottom: 0.5rem;
                font-size: 2rem;
                '''
            )

            ui.echart({
                'color': ["#8399be"], 
                'tooltip': {'trigger': 'axis'},
                'grid': {'left': '5%', 'right': '5%', 'bottom': '5%', 'containLabel': True},
                'xAxis': {
                    'type': 'category',
                    'data': etiquetas,
                    'axisLine': {
                        'lineStyle': {
                            'color': '#94a3b8'
                        }
                    },  # gris suave
                    'axisLabel': {'color': '#475569'}  # gris azulado oscuro
                },
                'yAxis': {
                    'type': 'value',
                    'min': 0,
                    'axisLine': {'show': False},
                    'splitLine': {
                        'lineStyle': {
                            'color': '#e2e8f0'
                        }
                    },  # gris clarito para líneas de división
                    'axisLabel': {'color': '#475569'}
                },
                'series': [{
                    'data': valores,
                    'type': 'bar',
                    'barWidth': '50%',
                    'itemStyle': {
                        'color': "#8399be",
                        'borderRadius': [4, 4, 0, 0]
                    }
                }]
            }).style('width:100%; height:350px;')


        # LADO DERECHO: Tabla de turnos
        with ui.column().classes('tabla-turnos-custom').style(
            '''
            background: white;
            border-radius: 18px;
            padding: 2rem;
            width: 700px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.08);
            color: #1e293b;
            display: flex;
            flex-direction: column;
            '''
        ):
            ui.label('Turnos Próximos').classes('titulo-turnos').style(
                '''
                text-align: center; 
                width: 100%;
                font-family: "Playfair Display", serif;
                color: #1e293b;
                text-align: center;
                margin-bottom: 0.5rem;
                font-size: 2rem;
                '''
            )
            if not rows:
                ui.label('Todavía no tenés turnos programados. ¡Agendá el primero!').classes(
                    'text-lg text-center text-gray-600 py-8'
                )
            else:
                ui.table(
                    columns=columns,
                    rows=rows
                ).props(
                    'virtual-scroll flat :rows-per-page="0" table-style="max-height: 300px;"'
                ).style(
                    '''
                    text-align: center; 
                    width: 100%;
                    background: transparent;
                    color: #1e293b;
                    font-size: 1.15rem;
                    max-height: 300px;
                    overflow-y: auto;
                    '''
                )


