from nicegui import ui  # o el import que uses para 'ui'
from controladores.logica_registro import registrar_veterinario, validar_datos_registro
from modelos.dbbroker import SupabaseBroker
from vistas.administradorPerfil import AdministradorPerfil
from vistas.encuesta import Encuesta

db = SupabaseBroker()
admin = AdministradorPerfil(db)
encuesta = Encuesta()  # usa sqlite:///jobs.sqlite por defecto

@ui.page('/register')
def register():
    """
    Página de registro para veterinarios en VetManager Peluchitos.
    Contiene formulario para registro con validaciones y envío de datos.
    """
    ui.add_head_html('''
        <style>
            /* aquí va todo el CSS que tenías */
            html, body {
                margin: 0;
                padding: 0;
                height: 100%;
                font-family: 'Poiret One', sans-serif;
                background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                            url('https://img.freepik.com/vector-premium/ilustracion-vectorial-patron-costuras-pata-gato-huella-pata-gato-aislada-sobre-fondo-blanco_478768-259.jpg?w=2000');
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                overflow: hidden;
            }
            .titulo-vet {
                top: 20px;
                left: 20px;
                color: #1e293b;
                font-size: 80px;
                font-weight: bold;
                font-family: 'Playfair Display', serif;
                user-select: none; 
                cursor: default;
                margin-bottom: 30px; /* Espacio debajo del título */
                text-align: center;
            }
            .custom-input input {
                color: #1e293b;
            }
        </style>
    ''')

    with ui.column().style('''
            width: 100vw;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        '''):
        with ui.card().classes('p-10 shadow-xl').style('''
                width: 550px;
                background-color: #ffffff;
                border-radius: 24px;
                color: #1e293b;
            '''):

            ui.label('🐾 Peluchitos').classes('titulo-vet')
            ui.label('Registro de Veterinarios')\
                .classes('text-3xl font-semibold mb-6 text-gray-700')

            # Aquí sigue todo tu código original para los inputs y botones

            with ui.row().classes('w-full mb-4').style('position: relative; align-items: center;'):
                ui.icon('person').style('position: absolute; left: 12px; color: #1e293b; font-size: 24px;')
                nombre = ui.input().props('outlined dense clearable').classes('w-full custom-input focus:border-blue-500').props('placeholder="Nombre completo"').style('padding-left: 42px;')

            with ui.row().classes('w-full mb-4').style('position:relative; align-items:center;'):
                ui.icon('badge').style('position:absolute; left:12px; color:#1e293b; font-size:24px;')
                matricula = ui.input().props('outlined dense clearable').classes('w-full custom-input focus:border-blue-500').props('placeholder="Número de matrícula"').style('padding-left:42px;')

            with ui.row().classes('w-full mb-4').style('position: relative; align-items: center;'):
                ui.icon('email').style('position: absolute; left: 12px; color: #1e293b; font-size: 24px;')
                email = ui.input().props('outlined dense type=email clearable').classes('w-full custom-input focus:border-blue-500').props('placeholder="Correo electrónico"').style('padding-left: 42px;')

            with ui.row().classes('w-full mb-4').style('position: relative; align-items: center;'):
                ui.icon('lock').style('position: absolute; left: 12px; color: #1e293b; font-size: 24px;')
                password = ui.input().props('outlined dense type=password clearable').classes('w-full custom-input focus:border-blue-500').props('placeholder="Contraseña"').style('padding-left: 42px;')

            with ui.row().classes('w-full mb-6').style('position: relative; align-items: center;'):
                ui.icon('lock').style('position: absolute; left: 12px; color: #1e293b; font-size: 24px;')
                confirm_password = ui.input().props('outlined dense type=password clearable').classes('w-full custom-input focus:border-blue-500').props('placeholder="Confirmar contraseña"').style('padding-left: 42px;')

            ui.label('Te enviaremos un correo de confirmación una vez que te registres.')\
                .classes('text-sm text-gray-500 mb-6')

            def registrar():
                es_valido, mensaje = validar_datos_registro(
                    nombre.value,
                    email.value,
                    password.value,
                    confirm_password.value,
                    matricula.value
                )

                if not es_valido:
                    ui.notify(mensaje, type='warning')
                    return

                ok, mensaje = registrar_veterinario(
                    admin,
                    encuesta,
                    email.value,
                    nombre.value,
                    password.value,
                    matricula.value
                )

                tipo = 'positive' if ok else 'negative'
                ui.notify(mensaje, type=tipo, timeout=5000)

                if ok:
                    ui.run_javascript("window.location.href = '/login';")

            ui.button('REGISTRARSE', on_click=registrar).props('color=primary unelevated').classes(
                'w-full py-3 text-lg font-semibold').style('border-radius: 8px;')

            ui.html('''
                <p style="color: #cccc; text-align: center; margin-top: 1rem; font-size: 0.9rem;">
                    ¿Ya tienes cuenta?
                    <a href="/login" style="color: #42a5f5; text-decoration: none; font-weight: 600;">Inicia sesión aquí</a>
                </p>
            ''')